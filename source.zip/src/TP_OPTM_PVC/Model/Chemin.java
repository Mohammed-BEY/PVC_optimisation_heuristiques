package TP_OPTM_PVC.Model;

import java.util.ArrayList;
import java.util.Iterator;

public class Chemin {

    private ArrayList<Arc> arcs;
    private double eval;

    public Chemin(ArrayList<Arc> arcs, double eval) {
        super();
        this.arcs = arcs;
        this.eval = eval;
    }

    public Chemin() {
        super();
        this.arcs = new ArrayList<>();
        this.eval = 0;
    }

    /**
     * @return the arcs
     */
    public ArrayList<Arc> getArcs() {
        return arcs;
    }

    /**
     * @param arcs the arcs to set
     */
    public void setArcs(ArrayList<Arc> arcs) {
        this.arcs = arcs;
    }

    /**
     * @return the eval
     */
    public double getEval() {
        return eval;
    }

    /**
     * @param eval the eval to set
     */
    public void setEval(double eval) {
        this.eval = eval;
    }

    public void AfficherChemin() {
        Iterator<Arc> it = arcs.iterator();
        Arc a;
        while (it.hasNext()) {
            a = it.next();
            System.out.println(" *" + a.getSommet1() + "*" + a.getSommet2());
        }
    }

    public String chemin_finale(int vi, int NbrSommets) {
        String ch = new String("");
        ArrayList<Arc> tmp = new ArrayList<>();
        tmp.addAll(arcs);
        int nbr = 0;
        while (nbr < tmp.size()) {
            Iterator<Arc> it = tmp.iterator();
            Arc arc = null;
            while (it.hasNext()) {
                arc = it.next();
                if (arc.getSommet1() == vi) {
                    ch = ch.concat(" , " + arc.getSommet1() + "-" + arc.getSommet2());
                    //	System.out.println(ch);
                    vi = arc.getSommet2();
                    // tmp.remove(arc);
                    nbr++;
                    break;
                }
            }

        }
        return ch;
    }

    // Récupère le chemin final ordonné dans le cas ou les arcs sont des arretes i.e : le graphe est symétrique
    public String chemin_finale_Symetric(int vi, int NbrSommets) {
        String ch = new String("" + vi);
        ArrayList<Arc> tmp = new ArrayList<>();
        tmp.addAll(arcs);
        int nbr = 0;
        while (nbr < NbrSommets) {
            Iterator<Arc> it = tmp.iterator();
            Arc arc = null;
            while (it.hasNext()) {
                arc = it.next();
                if (arc.getSommet1() == vi) {
                    ch = ch.concat("-" + arc.getSommet2());
                    //	System.out.println(ch);
                    vi = arc.getSommet2();
                    tmp.remove(arc);
                    nbr++;
                    break;
                } else if (arc.getSommet2() == vi) {
                    ch = ch.concat("-" + arc.getSommet1());
                    //	System.out.println(ch);
                    vi = arc.getSommet1();
                    tmp.remove(arc);
                    nbr++;
                    break;
                }
            }

        }
        return ch;
    }

    public double coutSolution(Chemin chemin, Graphe graphe) {
        double cout = 0;

        ArrayList<Arc> arcs = chemin.getArcs();
        int nbArcs = arcs.size();
        int sommetI, sommetJ;
        double distanceij;
        for (int i = 0; i < nbArcs; i++) {
            sommetI = arcs.get(i).getSommet1();
            sommetJ = arcs.get(i).getSommet2();
            distanceij = graphe.distanceAB(sommetI, sommetJ);
            cout = cout + distanceij;
        }
        return cout;
    }

    public boolean chercherArc(int som1, int som2) {
        boolean trouv = false;
        Iterator<Arc> it = this.arcs.iterator();
        Arc ar = new Arc();
        while (it.hasNext() && !trouv) {
            ar = it.next();
            if (ar.getSommet1() == som1 && ar.getSommet2() == som2) {
                trouv = true;
            }
        }
        return trouv;
    }
}
