package TP_OPTM_PVC.Model;

import java.util.ArrayList;
import java.util.Iterator;

public class Noeud {

    private double evaluation; // L'Evaluaion de ce Noeud
    private Graphe graphe; // Le graphe (la matrice de distance associ� � ce noeud
    private ArrayList<Arc> Ps; // L'ensemble des arcs pris dans la soltution
    private ArrayList<Arc> Ms; // L'ensemble des arcs exclus de la solution
    private boolean visite; // variable indiquant l'etat du noeud
    private ArrayList<String> chemin; // La list des chemins construits jusqu'� pr�sent

    public Noeud(Graphe graphe, int evaluation) {
        super();
        // this.filsGauche = filsGauche;
        // this.filsDroit = filsDroit;
        this.evaluation = evaluation;
        this.graphe = graphe;
        this.Ps = new ArrayList<>();
        this.Ms = new ArrayList<>();
        this.chemin = new ArrayList<>();
        this.visite = false;
    }

    public Noeud(int nbrsommets) {
        super();
        //	this.filsGauche = null;
        //	this.filsDroit = null;
        this.evaluation = 0;
        this.graphe = new Graphe(nbrsommets);
        this.Ps = new ArrayList<>();
        this.Ms = new ArrayList<>();
        this.chemin = new ArrayList<>();
        this.visite = false;
    }

    /**
     *
     * @param sommetInit : la valeur du sommets que nous voulons chercher si il
     * existe un arc dans Ps qui commence par ce noeud
     * @return : Si il existe des arcs dans PS qui commence par ce num sommet
     */
    public boolean isDebutPS(int sommetInit) {

        boolean trouv = false;

        Iterator<Arc> it = this.Ps.iterator();

        while (it.hasNext() && !trouv) {
            Arc a = it.next();
            if (a.getSommet1() == sommetInit) {
                trouv = true;
            }
        }
        return trouv;
    }

    /**
     *
     * @param sommetFinal : la valeur du sommets que nous voulons chercher si il
     * existe un arc dans Ps qui se termine par ce noeud
     * @return : Si il existe des arcs dans PS qui se termine par ce num sommet
     */
    public boolean isFinPS(int sommetFinal) {

        boolean trouv = false;

        Iterator<Arc> it = this.Ps.iterator();

        while (it.hasNext() && !trouv) {
            Arc a = it.next();
            if (a.getSommet2() == sommetFinal) {
                trouv = true;
            }
        }
        return trouv;
    }

    /**
     *
     * @param @return : la liste des numerots de sommets qui figure comme source
     * dans PS dans la liste "D" et ceux qui figure comme destination dans la
     * liste "F"
     */
    public void getDebut_Fin_PS(ArrayList<Integer> D, ArrayList<Integer> F) {

        Arc a = null;
        Iterator<Arc> it = this.Ps.iterator();
        while (it.hasNext()) {
            a = it.next();
            D.add(a.getSommet1());
            // System.out.println(" debut --- "+a.getSommet1());
            F.add(a.getSommet2());
            // System.out.println(" fin --- "+a.getSommet2());
        }

    }

    //	/**
    //	 * Elle permet de mettre  les distances � INFINY des arcs(vi,vj) qui sont dans PS {tq: vi est dans T-(Ps) et vj est dans T+(Ps)} 
    //	 * et cela afin d'eviter d'avoir des Sous-circuit
    //	 */
    //	public void MettreAjourDistance_PS(){
    //
    //		for(int i=0; i<this.graphe.getNbrSommets(); i++){
    //
    //			for(int j=0; j<this.graphe.getNbrSommets(); j++){
    //
    //				if(this.graphe.getValDistance(i, j)!=Double.POSITIVE_INFINITY){
    //
    //					if(isDebutPS(j) && isFinPS(i)) {
    //						this.graphe.setValDistance(i, j,Double.POSITIVE_INFINITY);
    //						//System.out.println(" / "+ i + " / "+ j);
    //					}
    //				}
    //
    //			}
    //
    //		}
    //	}
    /**
     * Elle permet de mettre les distances � INFINY de la ligne "i" et de la
     * colone"j"
     */
    public void Supprime_Ligne(int l, int c) {

        // Supprimer la ligne
        for (int j = 0; j < this.graphe.getNbrSommets(); j++) {

            this.graphe.setValDistance(l, j, Double.POSITIVE_INFINITY);
        }
        // supprimer la colone
        for (int i = 0; i < this.graphe.getNbrSommets(); i++) {
            this.graphe.setValDistance(i, c, Double.POSITIVE_INFINITY);
        }
    }

    //	/**
    //	 * Elle permet de construire le chemin depuis arc (vi , vj) avec les arcs dans PS
    //	 * Elle retourne l'arc qui est compos� (vi , vk) tq vk c'est le dernier sommet dans le chemin
    //	 */
    //	public Arc Construire_chemin(int vi,int vj){
    //
    //		ArrayList<Arc> chemin = new ArrayList<>(); // le chemin construit
    //
    //		Arc ar = new Arc(); 
    //
    //		Arc tmp = new Arc(); // Objet arc utilis� pour le parcourt de l'ensemble PS
    //
    //		ar.setSommet2(vi); // on rajoute le sommet d�part
    //		Iterator<Arc> it;
    //
    //		chemin.add(new Arc(vi,vj,0));
    //
    //		boolean trouv = false;
    //		while(chemin.size() != this.Ps.size()+1) // On parcourt tant qu'on a pas encore construit le chemin
    //		{
    //			it = this.Ps.iterator();
    //			while(it.hasNext()) {
    //				tmp = it.next();
    //				if (tmp.getSommet1()==vj) {
    //					chemin.add(new Arc(tmp.getSommet1(),tmp.getSommet2(),tmp.getDist())); // on rajoute l'Arc au chemin
    //					vj=tmp.getSommet2();
    //					trouv = true; 
    //				}
    //			}
    //			if (!trouv) break; // si on n'arrive pas � construire d�s le premier parcourt de PS le chemin on sort 
    //		}
    //
    //		if (trouv){
    //			ar.setSommet1(chemin.get(chemin.size()-1).getSommet2()); // on rajoute le sommet destination du dernier arc du chemin
    //			this.chemin.add(new String(""+ar.getSommet1()+""+ar.getSommet2())); // on sauvegarde que le debut et la fin du chemin 
    //		}
    //		else {
    //			ar.setSommet1(vj); // On n'a pas pu construire un chemin donc on retourne l'arc inverse (vj,vi) 
    //			ar.setSommet2(vi);
    //			this.chemin.add(new String(""+vj+""+vi)); // on sauvegarde que le debut et la fin du chemin 
    //		}
    //		return ar;
    //	}
    /**
     * Elle permet de construire la liste des chemins possibles dans cette
     * solution apr�s l'ajout de l'arc (vi,vj) Et aussi de supprimer les arcs
     * (vk,vl) qui risque de construire un sous-cycle
     */
    public void Construire_Chemins_EnleverSous_Cycle(int vi, int vj) {

        if (this.chemin.size() != 0) // c'est pas vide 
        {
            Iterator<String> it = this.chemin.iterator();
            ArrayList<String> newChemin = new ArrayList<>(); // tableau des nouveaux chemins construits 
            String tmp;
            boolean trouv = false;

            while (it.hasNext()) {
                tmp = it.next();
                // chercher ou placer notre nouveau arc au debut ou � la fin
                // On r�cup�re les duex sommets du chemin
                String[] tab = tmp.split("-");

                int s1 = Integer.parseInt(tab[0]);
                int s2 = Integer.parseInt(tab[1]);

                if (vi == s2) { // le nouveau arc se placera � la fin du chemin

                    newChemin.add(new String("" + s1 + "-" + vj)); // on rajoute le nouveau chemin
                    trouv = true; // on a trouver un chemin

                    this.graphe.setValDistance(vj, s1, Double.POSITIVE_INFINITY); // On marque l'arc (vj,s1) � l'infiny pour enlever les sous cycle
                    //	System.out.println(" Arc ENLEVER est : "+vj+ " - "+ s1) ;
                } else if (vj == s1) { // le nouveau arc se placera au debut du chemin

                    newChemin.add(new String("" + vi + "-" + s2)); // on rajoute le nouveau chemin
                    trouv = true; // on a trouver un chemin

                    this.graphe.setValDistance(s2, vi, Double.POSITIVE_INFINITY); // On marque l'arc (vj,s1) � l'infiny pour enlever les sous cycle
                    //	System.out.println(" Arc ENLEVER est : "+s2+ " - "+ vi) ;
                } else {
                    //	System.out.println(" Arc gard� est : "+s1+ " - "+ s2) ;
                    newChemin.add(new String("" + s1 + "-" + s2)); // on garde l'ancien chemin
                    // On ne supprime pas cet arc car on la fait dans l'etape pr�cedente
                }

            }
            if (!trouv) { // on n'a pas pu trouver un chemin � completer

                newChemin.add(new String("" + vi + "-" + vj)); // on rajoute le nouveau arc comme chemin
                this.graphe.setValDistance(vj, vi, Double.POSITIVE_INFINITY); // On marque l'arc (vj,s1) � l'infiny pour enlever les sous cycle
                //	System.out.println(" Arc ENLEVER est : "+vj+ " - "+ vi) ;
            }
            this.chemin.clear();// supprimer tous les chemin
            this.chemin.addAll(newChemin); // on remet les chemins construit dans la liste des chemins
            newChemin = null;
        } else {
            this.chemin.add(new String("" + vi + "-" + vj)); // on rajoute le nouveau arc comme chemin
            this.graphe.setValDistance(vj, vi, Double.POSITIVE_INFINITY); // On marque l'arc (vj,s1) � l'infiny pour enlever les sous cycle
            //	System.out.println(" Arc ENLEVER est : "+vj+ " - "+ vi) ;
        }
    }

    public void supprimer_cycle(int vi, int vj, int NbrSommets) {
        // int[] vinit =new int[NbrSommets];
        ArrayList<Integer> vinit = new ArrayList<>();
        vinit.add(vi);
        int saveVj = vj;
        int i = 1;
        ArrayList<Arc> tmp = new ArrayList<>();
        tmp.addAll(this.Ps);
        Iterator<Arc> it;
        Arc arc = null;
        boolean trouv = true;
        while (trouv) {
            trouv = false;
            it = tmp.iterator();
            while (it.hasNext()) {
                arc = it.next();
                if (arc.getSommet1() == vj) {
                    vinit.add(i, vj);
                    i++;
                    trouv = true;
                    for (int j = 0; j < i; j++) {
                        this.graphe.setValDistance(arc.getSommet2(), vinit.get(j), Double.POSITIVE_INFINITY);
                        //	System.out.println(" Arc ENLEVER est : "+arc.getSommet2()+ " - "+ vinit.get(j)) ;
                    }
                    vj = arc.getSommet2();
                    break;
                }
            }
        }
        vinit.add(i, vj);
        i = 1;
        vj = saveVj;
        ArrayList<Integer> vinit2 = new ArrayList<>();
        vinit2.add(0, vj);
        Iterator<Arc> itt;
        trouv = true;
        while (trouv) {
            trouv = false;
            itt = tmp.iterator();
            while (itt.hasNext()) {
                arc = itt.next();
                if (arc.getSommet2() == vi) {
                    vinit2.add(i, vi);
                    i++;
                    trouv = true;
                    for (int j = 0; j < i; j++) {
                        this.graphe.setValDistance(vinit2.get(j), arc.getSommet1(), Double.POSITIVE_INFINITY);
                        //	System.out.println(" Arc ENLEVER est : "+vinit2.get(j)+ " - "+arc.getSommet1() ) ;
                    }
                    for (int j = 0; j < vinit.size(); j++) {
                        this.graphe.setValDistance(vinit.get(j), arc.getSommet1(), Double.POSITIVE_INFINITY);
                        //	System.out.println(" Arc ENLEVER est : "+vinit.get(j)+ " - "+arc.getSommet1() ) ;
                    }
                    vi = arc.getSommet1();
                    break;
                }
            }
        }
    }

    /**
     *
     * @param distS : la matricce � copier dans la matrice distance du Noeud en
     * cours
     * @param taille : la dimension de la matrice
     */
    public void CopierMatriceDistance(double[][] distS, int taille) {

        for (int i = 0; i < this.graphe.getNbrSommets(); i++) {
            for (int j = 0; j < this.graphe.getNbrSommets(); j++) {
                this.graphe.setValDistance(i, j, distS[i][j]);
            }
        }
    }

    /**
     * @return the visite
     */
    public boolean isVisite() {
        return visite;
    }

    /**
     * @param visite the visite to set
     */
    public void setVisite(boolean visite) {
        this.visite = visite;
    }

    /**
     * @return the evaluation
     */
    public double getEvaluation() {
        return evaluation;
    }

    /**
     * @param evaluation the evaluation to set
     */
    public void setEvaluation(double evaluation) {
        this.evaluation = evaluation;
    }

    /**
     * @return the graphe
     */
    public Graphe getGraphe() {
        return graphe;
    }

    /**
     * @param graphe the graphe to set
     */
    public void setGraphe(Graphe graphe) {
        this.graphe = graphe;
    }

    /**
     * @return the ps
     */
    public ArrayList<Arc> getPs() {
        return Ps;
    }

    /**
     * @param ps the ps to set
     */
    public void setPs(ArrayList<Arc> ps) {
        Ps = ps;
    }

    /**
     * @return the ms
     */
    public ArrayList<Arc> getMs() {
        return Ms;
    }

    /**
     * @param ms the ms to set
     */
    public void setMs(ArrayList<Arc> ms) {
        Ms = ms;
    }

    /**
     * @return the chemin
     */
    public ArrayList<String> getChemin() {
        return chemin;
    }

    /**
     * @param chemin the chemin to set
     */
    public void setChemin(ArrayList<String> chemin) {
        this.chemin = chemin;
    }

}
