/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TP_OPTM_PVC.Model;

import static TP_OPTM_PVC.FXMLDocumentController.contPrinc;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author mohammed
 */
public class PVC_Data {

    public List<String> listeTransiton = new ArrayList<>();//contient les villes et les distances entre ces villes

    public PVC_Data() {
    }

    //récuperer le graphe des villes
    public String graphStatus(Chemin ch) {
        String result = "digraph" + "\n{\n" + "rankdir=LR;\n" + "node [shape = circle, width = 0.5];\n";
        int k = 0, size = listeTransiton.size();
        for (int i = 0; i < size; i++) {
            String[] tab = listeTransiton.get(i).split(" ");
            k = 0;
            if (k < tab.length) {
                result += tab[k] + "->";
                k += 2;
            }
            if (k < tab.length) {
                result += tab[k];
                k--;
            }
            if (k < tab.length) {
                int som1 = Integer.parseInt(tab[k - 1]);
                int som2 = Integer.parseInt(tab[k + 1]);
                if (ch.chercherArc(som1, som2)) {
                    result += "[label=\"" + tab[k] + "\",weight=\"" + tab[k] + "\" style = filled, fillcolor=palegreen];\n";
                } else {
                    result += "[label=\"" + tab[k] + "\",weight=\"" + tab[k] + "\"];\n";
                }
            }
        }
        result += "}";
        return result;
    }

    //insérer un arc dans la liste des Arcs
    public void insererArc() {
        listeTransiton.clear();
        int j = contPrinc.getChildren().size();
        String tmp = "";
        for (int k = 1; k < j; k++) {
            tmp = contPrinc.getChildren().get(k).toString();
            if (!listeTransiton.contains(tmp)) {
                listeTransiton.add(tmp);
            }
        }
    }

}
