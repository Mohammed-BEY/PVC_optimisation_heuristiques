package TP_OPTM_PVC.Model;

import TP_OPTM_PVC.IHM.Point;
import java.util.Random;

public class Graphe {

    public Point[] tabPoint; //ensemble des points
    private double[][] distance; // Tableau des distances entre le noeuds du graphe
    private int nbrSommets; // le nombre de sommets
    int xMax;
    int yMax;

    public Graphe(int nbrSommets) {
        super();
        distance = new double[nbrSommets][nbrSommets];
        this.nbrSommets = nbrSommets;
        initialiserDistance();
    }

    public Graphe() {
        distance = new double[nbrSommets][nbrSommets];
    }

    /**
     * Constructeur
     *
     * @param nbP le nombre de point du graphe
     * @param xMax la valeur maximam d'un point sur x
     * @param yMax la valeur maximam d'un point sur y
     */
    public Graphe(int nbrSommets, int xMax, int yMax) {
        distance = new double[nbrSommets][nbrSommets];
        this.nbrSommets = nbrSommets;
//        initialiserDistance();
        this.xMax = xMax;
        this.yMax = yMax;

        tabPoint = new Point[nbrSommets];

        randTabPoint();

//        distance = new double[nbrSommets][nbrSommets];
//        calcTabDist();
    }

    //remplir la diagonale de la matrice avec la valeur NULL
    public void initialiserDistance() {
        for (int i = 0; i < this.nbrSommets; i++) {
            distance[i][i] = Double.POSITIVE_INFINITY;
        }
    }

    public double getValDistance(int i, int j) {
        return distance[i][j];
    }

    public void setValDistance(int i, int j, double val) {
        distance[i][j] = val;
    }

    public double[][] getDistance() {
        return distance;
    }

    public void setDistance(double[][] distance) {
        this.distance = distance;
    }

    public int getNbrSommets() {
        return nbrSommets;
    }

    public void setNbrSommets(int nbrSommets) {
        this.nbrSommets = nbrSommets;
    }

    //récupérer la distance entre une paire de somemts
    public double distanceAB(int sommet1, int sommet2) {
        return distance[sommet1][sommet2];
    }

    /**
     * Construit al�atoirment les points
     */
    public void randTabPoint() {
        Random r = new Random();

        for (int i = 0; i < nbrSommets; ++i) {
            Point tmp = Point.randomPoint(r, xMax, yMax);
            while (isAllreadyPresent(tmp)) {
                tmp = Point.randomPoint(r, xMax, yMax);
            }
            tabPoint[i] = tmp;
        }
    }

    /**
     * Cherche si un point est d�j� dans le graphe
     *
     * @param p le point p
     * @return vrai si le point est d�j� dans le graphe, faux sinon
     */
    public boolean isAllreadyPresent(Point p) {
        int i = 0;
        while (tabPoint[i] != null) {
            if (p.getX() == tabPoint[i].getX()) {
                if (p.getY() == tabPoint[i].getY()) {
                    return true;
                }
            }
            ++i;
        }
        return false;
    }

    /**
     * Calcul la table des distances
     */
    public void calcTabDist() {
        for (int i = 0; i < nbrSommets; ++i) {
            for (int j = 0; j < nbrSommets; ++j) {
                if (i != j) {
                    distance[i][j] = tabPoint[i].calcDist(tabPoint[j]);
                }
            }
        }
    }
}
