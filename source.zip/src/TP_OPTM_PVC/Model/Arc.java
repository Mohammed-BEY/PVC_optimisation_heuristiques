package TP_OPTM_PVC.Model;

public class Arc implements Comparable<Arc> {

    private int sommet1;
    private int sommet2;
    private double dist;

    public Arc(int sommet1, int sommet2, double dist) {
        super();
        this.sommet1 = sommet1;
        this.sommet2 = sommet2;
        this.dist = dist;
    }

    public Arc() {
        super();
        this.sommet1 = 0;
        this.sommet2 = 0;
        this.dist = 0;
    }

    /**
     * @return the sommet1
     */
    public int getSommet1() {
        return sommet1;
    }

    /**
     * @param sommet1 the sommet1 to set
     */
    public void setSommet1(int sommet1) {
        this.sommet1 = sommet1;
    }

    /**
     * @return the sommet2
     */
    public int getSommet2() {
        return sommet2;
    }

    /**
     * @param sommet2 the sommet2 to set
     */
    public void setSommet2(int sommet2) {
        this.sommet2 = sommet2;
    }

    /**
     * @return the dist
     */
    public double getDist() {
        return dist;
    }

    /**
     * @param distance the dist to set
     */
    public void setDist(double dist) {
        this.dist = dist;
    }

    @Override
    public int compareTo(Arc o) {
        if (this.dist > o.getDist()) {
            return 1;
        } else if (this.dist == o.getDist()) {
            return 0;
        } else {
            return -1;
        }
    }

    //redéfnir la méthode toString
    @Override
    public String toString() {
        return sommet1 + " " + dist + " " + sommet2;
    }

}
