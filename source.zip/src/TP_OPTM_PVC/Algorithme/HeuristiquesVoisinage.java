/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TP_OPTM_PVC.Algorithme;

import TP_OPTM_PVC.Model.Arc;
import TP_OPTM_PVC.IHM.ArcDessin;
import TP_OPTM_PVC.Model.Chemin;
import TP_OPTM_PVC.Model.Graphe;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author mohammed
 */
public class HeuristiquesVoisinage {

    public ArrayList tabDessin;// contient les �tapes du dessin

    public HeuristiquesVoisinage() {
        tabDessin = new ArrayList();
    }

    public Chemin ameliorerSolution_2_OPT(Chemin chemin, Graphe g) {
        boolean amelioration = true;
        int sommetI, sommetJ, sommetK, sommetL;
        int nbArcs = chemin.getArcs().size();
        double ijkl, ikjl;
        double distanceij, distancejl, distanceik, distancekl;
        Chemin meilleureSolutionCourante = new Chemin();//Le chemin qui représente la meilleure solution courante
        //copier les arcs de la solution initiale dans la solution courante
        for (Arc arc : chemin.getArcs()) {
            meilleureSolutionCourante.getArcs().add(new Arc(arc.getSommet1(), arc.getSommet2(), arc.getDist()));
        }

        //Créer un chemin temporaire pour le parcours et l'amélioration
        Chemin cheminTmp = new Chemin();
        //copier les arcs de la solution initiale dans le chemin courant
        for (Arc arc : chemin.getArcs()) {
            cheminTmp.getArcs().add(new Arc(arc.getSommet1(), arc.getSommet2(), arc.getDist()));
        }
        //Instancier un chemin qui permet de permuter le 2 arcs avec la méthode 2-OPT
        Chemin cheminPermutation2_OPT = new Chemin();
        for (Arc arc : cheminTmp.getArcs()) {
            cheminPermutation2_OPT.getArcs().add(new Arc(arc.getSommet1(), arc.getSommet2(), arc.getDist()));
        }

        while (amelioration) {
            //on quitte quand il n'y a plus d'amélioration possible du chemin
            amelioration = false;
            for (int i = 0; i < nbArcs - 2; i++) {//parcourir la liste des sommets
//                System.out.println("ArcI:" + i + ":" + cheminTmp.getArcs().get(i).toString());
                for (int j = i + 2; j < nbArcs; j++) {
//                    System.out.println("ArcJ:" + j + ":" + cheminTmp.getArcs().get(j).toString());
                    sommetI = cheminTmp.getArcs().get(i).getSommet1();
                    sommetJ = cheminTmp.getArcs().get(i).getSommet2();
                    sommetK = cheminTmp.getArcs().get((j)).getSommet1();
                    sommetL = cheminTmp.getArcs().get((j)).getSommet2();

                    distanceij = g.distanceAB(sommetI, sommetJ);
                    distancekl = g.distanceAB(sommetK, sommetL);
                    distanceik = g.distanceAB(sommetI, sommetK);
                    distancejl = g.distanceAB(sommetJ, sommetL);
                    ijkl = distanceij + distancekl;
                    ikjl = distanceik + distancejl;
//                    System.out.println("i:" + sommetI + " ,j:" + sommetJ + " ,DistanceIJ:" + distanceij + " ,k:" + sommetK + " ,l:" + sommetL + " ,DistancekL:" + distancekl + "  ,DistanceIK" + distanceik + "  ,DistanceJL:" + distancejl + "  ,IJKL:" + ijkl + "   ,IKJL:" + ikjl);
                    if (ikjl < ijkl) {//on prend le nouveau renversement des villes
                        //Faire les permutations pour comparer avec la meilleure solution
                        cheminPermutation2_OPT.getArcs().clear();
                        for (Arc arc : cheminTmp.getArcs()) {
                            cheminPermutation2_OPT.getArcs().add(new Arc(arc.getSommet1(), arc.getSommet2(), arc.getDist()));
                        }
                        for (int k = 0; k < cheminTmp.getArcs().size(); k++) {
                            sommetI = cheminTmp.getArcs().get(k).getSommet1();
                            sommetJ = cheminTmp.getArcs().get(k).getSommet2();
                            distanceij = cheminTmp.getArcs().get(k).getDist();
                            cheminPermutation2_OPT.getArcs().get(k).setSommet1(sommetI);
                            cheminPermutation2_OPT.getArcs().get(k).setSommet2(sommetJ);
                            cheminPermutation2_OPT.getArcs().get(k).setDist(distanceij);
                        }
                        permuter2_OPT(cheminPermutation2_OPT, i, j, g);
                        //On vérifie si le nouveau renversement améliore la meilleure solution courante
                        if (cheminPermutation2_OPT.coutSolution(cheminPermutation2_OPT, g) < meilleureSolutionCourante.coutSolution(meilleureSolutionCourante, g)) {
                            //mettre à jour la meilleure solution
                            for (int k = 0; k < cheminPermutation2_OPT.getArcs().size(); k++) {
                                sommetI = cheminPermutation2_OPT.getArcs().get(k).getSommet1();
                                sommetJ = cheminPermutation2_OPT.getArcs().get(k).getSommet2();
                                distanceij = cheminPermutation2_OPT.getArcs().get(k).getDist();
                                meilleureSolutionCourante.getArcs().get(k).setSommet1(sommetI);
                                meilleureSolutionCourante.getArcs().get(k).setSommet2(sommetJ);
                                meilleureSolutionCourante.getArcs().get(k).setDist(distanceij);
                            }
                            //on réinitialise l'amélioration pour une éventuelle solution meilleure
                            amelioration = true;
                        }
                    }
                }
            }
            if (amelioration) {//il y a possibilité d'amélioration
                for (int k = 0; k < meilleureSolutionCourante.getArcs().size(); k++) {
                    sommetI = meilleureSolutionCourante.getArcs().get(k).getSommet1();
                    sommetJ = meilleureSolutionCourante.getArcs().get(k).getSommet2();
                    distanceij = meilleureSolutionCourante.getArcs().get(k).getDist();
                    cheminTmp.getArcs().get(k).setSommet1(sommetI);
                    cheminTmp.getArcs().get(k).setSommet2(sommetJ);
                    cheminTmp.getArcs().get(k).setDist(distanceij);
                }
            }
        }
        //remplir la liste des arcs pour le dessin
        Arc tmp = null;
        tabDessin.clear();
        for (Arc arc : meilleureSolutionCourante.getArcs()) {
            tmp = new Arc(arc.getSommet1(), arc.getSommet2(), arc.getDist());
            tabDessin.add(new ArcDessin(tmp)); // Pour le dessin
        }
        return meilleureSolutionCourante;
    }

    public Chemin ameliorerSolution_Node_Reinsertion(Chemin chemin, Graphe g) {
        Chemin meilleureSolutionCourante = new Chemin();//Le chemin qui représente la meilleure solution courante
        //copier les arcs de la solution initiale dans la solution courante 
        for (Arc arc : chemin.getArcs()) {
            meilleureSolutionCourante.getArcs().add(new Arc(arc.getSommet1(), arc.getSommet2(), arc.getDist()));
        }

        //Créer un chemin temporaire pour le parcours et l'amélioration
//        Chemin cheminTmp = new Chemin();
//        cheminTmp.getArcs().addAll(chemin.getArcs());
        //Créer un chemin temporaire qui contient le résultat du déplacement d'un noeud
        Chemin cheminDeplacementNoeud = new Chemin();
        int k = 0, sommetEnl;
        int nbArcs = chemin.getArcs().size();
        for (int i = 0; i < nbArcs; i++) {
            sommetEnl = chemin.getArcs().get(i).getSommet1();
            for (int j = 0; j < nbArcs; j++) {//parcourir la liste des arcs
                k = i - 1;
                if (k < 0) {
                    k += nbArcs;
                }
                if ((j != i) && (j != k)) {
                    //insérer le sommet 'i' dans l'arc 'j' et reconstruire un nouveau chmein
                    cheminDeplacementNoeud = construireChemin_Node_Reinsertion(chemin, sommetEnl, i, j, g);
                    //Comparer le résultat du changement avec le chemin temporaite avant le changement
//                    if (cheminDeplacementNoeud.coutSolution(cheminDeplacementNoeud, g) < chemin.coutSolution(chemin, g)) {
                    //mattre à jour la variable temporaire
                    //Comparer la solution courante avec la meilleure solution
                    if (cheminDeplacementNoeud.coutSolution(cheminDeplacementNoeud, g) < meilleureSolutionCourante.coutSolution(meilleureSolutionCourante, g)) {
                        //mettre à jour la meilleure solution
                        meilleureSolutionCourante.getArcs().clear();
                        for (Arc arc : cheminDeplacementNoeud.getArcs()) {
                            meilleureSolutionCourante.getArcs().add(new Arc(arc.getSommet1(), arc.getSommet2(), arc.getDist()));
                        }
                    }
//                    }
                }
            }
        }
        //remplir la liste des arcs pour le dessin
        Arc tmp = null;
        tabDessin.clear();
        for (Arc arc : meilleureSolutionCourante.getArcs()) {
            tmp = new Arc(arc.getSommet1(), arc.getSommet2(), arc.getDist());
            tabDessin.add(new ArcDessin(tmp)); // Pour le dessin
        }

        return meilleureSolutionCourante;
    }

    //construire un nouveau chemin en enlevant le 'sommet' qui est en entrée et l'insérant dans l'arc nméro 'numArc'
    //sommetEnl: le sommet à enlever
    //numArcEnl: l'arc où il appartient le sommet
    //numArcInserer: le numéro de l'arc où insérer le sommet
    private Chemin construireChemin_Node_Reinsertion(Chemin chemin, int sommetEnl, int numArcEnl, int numArcInserer, Graphe g) {
        Chemin cheminTmp = new Chemin();
//        System.out.println("****************************************************Result TMP:" + sommetEnl + "-" + numArcInserer + "-" + numArcEnl + "**************************************");
        for (Arc arc : chemin.getArcs()) {
            cheminTmp.getArcs().add(new Arc(arc.getSommet1(), arc.getSommet2(), arc.getDist()));
        }
        //: sauvegarder le 2è sommet de l'Arc où insérer le nouveau somemt
        int sommetSauv = cheminTmp.getArcs().get(numArcInserer).getSommet2();
//        System.out.println("Sommet2 où insérer le nouveau sommet:" + sommetSauv);
        //Première modification
        cheminTmp.getArcs().get(numArcInserer).setSommet2(sommetEnl);
        cheminTmp.getArcs().get(numArcInserer).setDist(g.distanceAB(cheminTmp.getArcs().get(numArcInserer).getSommet1(), sommetSauv));
        //Deuxième modification: créer un arc au niveau à l'indice numArcIns+1
        cheminTmp.getArcs().add(numArcInserer + 1, new Arc(sommetEnl, sommetSauv, g.distanceAB(sommetEnl, sommetSauv)));
//        System.out.println("SommetInséré:" + cheminTmp.getArcs().get(numArcInserer + 1).toString());
        //supprimer l'arc qui contient le sommet à enlver comme sommet1
        //sauvegarder le 2è sommet de l'arc courant à enlver
        if (numArcInserer < numArcEnl) {
            sommetSauv = cheminTmp.getArcs().get(numArcEnl + 1).getSommet2();
            cheminTmp.getArcs().remove(numArcEnl + 1);
        } else {
            sommetSauv = cheminTmp.getArcs().get(numArcEnl).getSommet2();
            cheminTmp.getArcs().remove(numArcEnl);
            numArcEnl--;
            if (numArcEnl < 0) {
                numArcEnl = cheminTmp.getArcs().size() - 1;
            }
        }
        //Troisième modification: affecter le sommet sauvegardé à enlver à l'arc précedent
        cheminTmp.getArcs().get(numArcEnl).setSommet2(sommetSauv);
        cheminTmp.getArcs().get(numArcEnl).setDist(g.distanceAB(cheminTmp.getArcs().get(numArcEnl).getSommet1(), sommetSauv));
        return cheminTmp;
    }

    public Graphe generateGraphe(int nbrSommets, int min, int max) {
        Graphe g = new Graphe(nbrSommets);
        Random R = new Random();
        double val = 0;
        DecimalFormat f = new DecimalFormat(".###"); // utilis�e pour tranquer en 3 chiffre apr� la virgule
        for (int i = 0; i < nbrSommets; i++) {
            for (int j = 0; j < nbrSommets; j++) {
                if (i == j) { // la diagonale
                    g.setValDistance(i, j, Double.POSITIVE_INFINITY);
                } else {
                    val = R.nextDouble() * (max - min) + min; // On g�n�re un nombre al�atoire dans [min max]
                    val = Double.parseDouble(f.format(val).replace(',', '.'));
                    g.setValDistance(i, j, val);
                }
            }
        }
        return g;
    }

    private void permuter2_OPT(Chemin solutionCourante, int arcIJ, int arcKL, Graphe graphe) {
        int sommetI = solutionCourante.getArcs().get(arcIJ).getSommet1(),
                sommetJ = solutionCourante.getArcs().get(arcIJ).getSommet2(),
                sommetK = solutionCourante.getArcs().get(arcKL).getSommet1(),
                sommetL = solutionCourante.getArcs().get(arcKL).getSommet2();

        solutionCourante.getArcs().get(arcIJ).setSommet2(sommetK);
        solutionCourante.getArcs().get(arcIJ).setDist(graphe.distanceAB(sommetI, sommetK));
        solutionCourante.getArcs().get(arcKL).setSommet1(sommetJ);
        solutionCourante.getArcs().get(arcKL).setDist(graphe.distanceAB(sommetJ, sommetL));
        //réordonner les arcs
        int cptL = 1, tmpSommetPermutation;
        int cptSommet1, cptSommet2;
        double cptDistance;
        for (int k = arcIJ + cptL; k <= arcKL - cptL; k++) {
            cptSommet1 = solutionCourante.getArcs().get(k).getSommet1();
            cptSommet2 = solutionCourante.getArcs().get(k).getSommet2();
            cptDistance = solutionCourante.getArcs().get(k).getDist();

            solutionCourante.getArcs().get(k).setSommet1(solutionCourante.getArcs().get(arcKL - cptL).getSommet1());
            solutionCourante.getArcs().get(k).setSommet2(solutionCourante.getArcs().get(arcKL - cptL).getSommet2());
            solutionCourante.getArcs().get(k).setDist(solutionCourante.getArcs().get(arcKL - cptL).getDist());

            solutionCourante.getArcs().get(arcKL - cptL).setSommet1(cptSommet1);
            solutionCourante.getArcs().get(arcKL - cptL).setSommet2(cptSommet2);
            solutionCourante.getArcs().get(arcKL - cptL).setDist(cptDistance);
            cptL++;
        }
        //ordonner la liste des arêtes selon l'ordre des sommets
        for (int k = arcIJ + 1; k < arcKL; k++) {
            tmpSommetPermutation = solutionCourante.getArcs().get(k).getSommet1();
            solutionCourante.getArcs().get(k).setSommet1(solutionCourante.getArcs().get(k).getSommet2());
            solutionCourante.getArcs().get(k).setSommet2(tmpSommetPermutation);
        }
    }
}
