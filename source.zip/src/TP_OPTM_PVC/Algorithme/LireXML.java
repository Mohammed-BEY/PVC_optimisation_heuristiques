package TP_OPTM_PVC.Algorithme;

import TP_OPTM_PVC.Model.Graphe;
import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

public class LireXML {

    static public Graphe matFromXML(String file) {
        Graphe g = null;
        try {
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(new File(file));
            // normalize text representation
            doc.getDocumentElement().normalize();

            NodeList listOfVertex = doc.getElementsByTagName("vertex");
            int nbsommet = listOfVertex.getLength();
            g = new Graphe(nbsommet);
            for (int s = 0; s < listOfVertex.getLength(); s++) {
                Node edgNode = listOfVertex.item(s);
                if (edgNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element firstPersonElement = (Element) edgNode;
                    //-------
                    NodeList firstNameList = firstPersonElement.getElementsByTagName("edge");
                    for (int j = 0; j < firstNameList.getLength(); j++) {
                        Element firstNameElement = (Element) firstNameList.item(j);
                        NodeList textFNList = firstNameElement.getChildNodes();
                        int num = Integer.parseInt(((Node) textFNList.item(0)).getNodeValue().trim());
                        double cout = Double.parseDouble((firstNameElement.getAttribute("cost")));
                        g.setValDistance(s, num, cout);
                    }
                }//end of if clause
            }//end of for loop with s var
        } catch (SAXParseException err) {
            System.out.println("** Parsing error" + ", line " + err.getLineNumber() + ", uri " + err.getSystemId());
            System.out.println(" " + err.getMessage());
        } catch (SAXException e) {
            Exception x = e.getException();
            ((x == null) ? e : x).printStackTrace();
        } catch (Throwable t) {
            t.printStackTrace();
        }
        //System.exit (0);
        return g;
    }//end of main

}
