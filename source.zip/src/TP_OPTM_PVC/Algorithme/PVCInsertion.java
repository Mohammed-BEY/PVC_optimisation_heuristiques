package TP_OPTM_PVC.Algorithme;

import TP_OPTM_PVC.Model.Arc;
import TP_OPTM_PVC.IHM.ArcDessin;
import TP_OPTM_PVC.Model.Chemin;
import TP_OPTM_PVC.Model.Graphe;
import TP_OPTM_PVC.Utilitaire;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class PVCInsertion {

    private Chemin chemin; // La liste ddes arcs dans le chemin 
    public ArrayList tabDessin;// contient les �tapes du dessin
    int nbrSommet;
    Graphe gr;

    public PVCInsertion() {
        super();
        chemin = new Chemin();
        tabDessin = new ArrayList();
    }

    /**
     *
     * @param g : le graphe de l'instance
     * @return : le chemin construit avec la methode de Nearrest insertion
     */
    public Chemin Nearest_insertion(Graphe g) {
        double Df = 0;

        nbrSommet = g.getNbrSommets();
        gr = new Graphe(g.getNbrSommets());
        Utilitaire.recopierMatrice(g.getDistance(), gr.getDistance(), nbrSommet);
        gr.setNbrSommets(g.getNbrSommets());

        ArrayList<Integer> SV = new ArrayList<>(); // La liste des sommets visit�s
        ArrayList<Integer> SNV = new ArrayList<>(); // La liste des sommets non visit�es

        InitialiserListSommetNonVisite(SNV, g.getNbrSommets()); // Initialiser la liste des sommets non visit�s

        // G�n�rer un Sommet initiale al�atoirement 
        int vi = 0; // Sommet initiale 
        Random ran = new Random();
        vi = ran.nextInt(g.getNbrSommets());
        // vi=0;
        int vj = Utilitaire.calculIndiceMin(g.getDistance(), vi, -1, g.getNbrSommets()); // calculer le plus proche voisin vj � vi
        // Rajouter vi et vj � la liste des sommets visit�s
        SV.add(vi);
        SV.add(vj);
//        System.out.println(" sommet vi = " + vi + " sommet vj = " +vj );
        // Rajouter l'arette (vi ,vj) au sous-chemin 
        this.chemin.getArcs().add(new Arc(vi, vj, g.getValDistance(vi, vj)));
        // M� j le cout du chemin 
        this.chemin.setEval(this.chemin.getEval() + g.getValDistance(vi, vj));

        // Enlever vi et vj de la liste des sommets non visit�s
        SNV.remove(Integer.valueOf(vi));
        SNV.remove(Integer.valueOf(vj));

        int vk = 0; // le sommet � ins�rer
        Arc arcMin = null; // l'arette � remplacer 

        //System.out.println(" arc initiale " + vi + "-" + vj);
        while (SV.size() < g.getNbrSommets()) { // Tnt qu'on a pas un cycle hamiltonien on continue
            vk = chercherPlusProche(SNV, SV, g.getDistance(), g.getNbrSommets()); // le sommet le plus proche � ins�rer

//            System.out.println(" sommet plus proche = " + vk);
            if (vk != -1) { // vk == -1 pour le dernier sommet du graphe 
                SNV.remove(Integer.valueOf(vk)); // On enl�ve vk de la liste des sommets non visit�s
                SV.add(vk); // rajouter vk � la liste des sommets visit�s 

                arcMin = rechercherArreteMin(this.chemin.getArcs(), vk, g.getDistance(), g.getNbrSommets()); // rechercher l'arette ou ins�rer vk (vl , vm)
//                System.out.println(" arc � remplacer = " + arcMin.getSommet1() + "-" + arcMin.getSommet2() + " par " + arcMin.getSommet1() + "-" + vk);

                this.chemin.getArcs().remove(arcMin); // on enl�ve l'arette du sous-Tour
                this.chemin.getArcs().add(new Arc(arcMin.getSommet1(), vk, g.getValDistance(arcMin.getSommet1(), vk))); // rajouter l'arrete (vl , vk)
                this.chemin.getArcs().add(new Arc(vk, arcMin.getSommet2(), g.getValDistance(vk, arcMin.getSommet2()))); // rajouter l'arrete (vm , vk)

                Df = g.getValDistance(arcMin.getSommet1(), vk) + g.getValDistance(arcMin.getSommet2(), vk) - arcMin.getDist(); // calculer l'augmentation en ins�rant vk entre (vl , vm)
                this.chemin.setEval(this.chemin.getEval() + Df); // M�j le cout du  sous-chemin
            }
        }
        // Rajouter l'arette pour former le cycle
        this.chemin.getArcs().add(new Arc(vj, vi, g.getValDistance(vj, vi)));
        // M� j le cout du chemin 
        this.chemin.setEval(this.chemin.getEval() + g.getValDistance(vj, vi));

        Iterator<Arc> it = this.chemin.getArcs().iterator();
        Arc arr;
//        while (it.hasNext()) {
//            arr = it.next();
//            System.out.println(" vi = " + arr.getSommet1() + "-- vj= " + arr.getSommet2() + " dist = " + arr.getDist());
//        }

        //System.out.println(" Chemin finale est : " + this.chemin.chemin_finale_Symetric(0, g.getNbrSommets()));
        //System.out.println(" le cout du chemin est : " + this.chemin.getEval());
        return this.chemin;
    }

    /**
     *
     * @param SNV : la liste de sommet non encore visit�s
     * @param SV : la liste de sommets visit�s
     * @param Diist : la matrice des distances du graphe
     * @param Tail : le nombre de sommet du graphe
     * @return : le sommet "k" appartenant � "SNV" ayant la plus petite distance
     * avec les sommets de "SV" d(k,T) = min (d(i,j)) j dans SV et i dans SNV
     */
    public int chercherPlusProche(ArrayList<Integer> SNV, ArrayList<Integer> SV, double[][] Dist, int Tail) {
        int vk = -1; // le sommet "k" appartenant � "SNV" ayant la plus petite distance avec les sommets de "SV" d(k,T) = min (d(i,j)) j dans SV et i dans SNV 

        double minDkT = Double.POSITIVE_INFINITY; // la plus petite distance entre le sommet k et les sommets du tour T ( les sommets dans SV)

        int somtmp; // variable temporaire

        for (Integer som : SV) { // Pour chaque sommet visit�

            somtmp = Utilitaire.calculIndiceMinLigne(Dist, som.intValue(), Tail, SNV); // On calcul le sommet le plus proche au sommet som qui est dans le tour
            if (somtmp != -1) {
                if (Dist[som][somtmp] < minDkT) { // On mimnimise la distance entre tous les sommets du tour et ceux non visit�s
                    minDkT = Dist[som][somtmp];
                    vk = somtmp;
                }
            }
        }

        return vk;
    }

    /**
     *
     * @param Tour : le sous-chemin construit jusqu'� pr�sent
     * @param sommetk : le sommet qu'on veut ins�rer dans le graphe
     * @param Dist : la matrice ddes distances du graphe
     * @param Tail : le nombre de sommets
     * @return l'arrete qui nous donne un cout minimal en inserant le sommet
     * "vk" au milieu
     */
    public Arc rechercherArreteMin(ArrayList<Arc> Tour, int Sommetk, double[][] Dist, int Tail) {

        Arc arcMin = new Arc();
        Arc ar = null;  // Variable pour le parccourt
        Iterator<Arc> it = Tour.iterator();

        double Dfmin = Double.POSITIVE_INFINITY;
        double Df = 0;

        while (it.hasNext()) {
            ar = it.next();
            Df = Dist[ar.getSommet1()][Sommetk] + Dist[Sommetk][ar.getSommet2()] - ar.getDist(); // calculer la valeur "Dalta f" = Cik + Ckj - Cij

            if (Df < Dfmin) {
                arcMin = ar;
                Dfmin = Df; // M�j la valeur Min
            }
        }

        return arcMin;
    }

    /**
     *
     * @param SNV : La liste � initialiser avec les num�ros de sommets non
     * visi�s
     * @param nbrSommet : Nombre de sommets (villes) dans le graphe
     */
    public void InitialiserListSommetNonVisite(ArrayList<Integer> SNV, int nbrSommet) {

        for (int i = 0; i < nbrSommet; i++) {
            SNV.add(i);
        }

    }

    public void remplirDessin() {
        //remplir la liste des arcs pour le dessin
        Arc tmp = null;
        tabDessin.clear();
        String chem = this.chemin.chemin_finale_Symetric(0, this.nbrSommet);
        Chemin ch = Utilitaire.StringToChemin(gr, chem);
        this.chemin.getArcs().clear();
        for (Arc arc : ch.getArcs()) {
            tmp = new Arc(arc.getSommet1(), arc.getSommet2(), arc.getDist());
            this.chemin.getArcs().add(new Arc(arc.getSommet1(), arc.getSommet2(), arc.getDist()));
            tabDessin.add(new ArcDessin(tmp)); // Pour le dessin
        }
    }

    public Chemin getChemin() {
        return chemin;
    }
  
    
}
