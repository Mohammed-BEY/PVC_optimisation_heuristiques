package TP_OPTM_PVC.Algorithme;

import TP_OPTM_PVC.Model.Arc;
import TP_OPTM_PVC.IHM.ArcDessin;
import TP_OPTM_PVC.Model.Chemin;
import TP_OPTM_PVC.Model.Graphe;
import TP_OPTM_PVC.Utilitaire;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class PVCClarkWright {

    Chemin chemin; // La liste ddes arcs dans le chemin 
    public ArrayList tabDessin;// contient les �tapes du dessin
    int nbrSommet;
    Graphe gr;

    public PVCClarkWright() {
        super();
        chemin = new Chemin();
        tabDessin = new ArrayList();
        nbrSommet = 0;
    }

    /**
     *
     * @param Dist : La matrice des Distances de notre instance
     * @param NbrSomm : le nombre de sommets dans l'instance
     * @param k : le sommet centrale
     * @return : La list des Savings ordonn�e dans l'ordre d�croissant
     */
    public ArrayList<Arc> CalculSavings(double[][] Dist, int NbrSomm, int k) {

        ArrayList<Arc> ListSaving = new ArrayList<>(); // La list des savings calcul�s

        int i = 0, j = 0; // variable pour parcourir la matrice des distances
        double Sij = 0; //le savings entre le sommet i et j 
        Arc ar = null;
        while (i < NbrSomm) {
            if (i != k) { // On ignore le noeud central
                j = i + 1; // on initialise j � i+1 pour recherche que dans la partie Sup de la mtrice car c'est symetrique

                while (j < NbrSomm) {
                    if (j != k) {
                        Sij = Dist[k][i] + Dist[k][j] - Dist[i][j]; // Calcul du "savings"
//                        System.out.println(" Sij " + i + "-" + j + " = " + Sij);
                        ar = new Arc(i, j, Sij);
                        ListSaving.add(ar);
                    }
                    j++;
                }
            }
            i++;
        }
        // Trier la list des savings par ordre d�croissant 
        Collections.sort(ListSaving, Collections.reverseOrder());

        return ListSaving;
    }

    /**
     *
     * @param g : le graphe du probl�me � r�soudre Elle permet de r�soudre le
     * probl�me avec la m�thode constructive de Clark & wright
     */
    public Chemin Clark_Wright(Graphe g) {
        nbrSommet = g.getNbrSommets();
        gr = new Graphe(g.getNbrSommets());
        Utilitaire.recopierMatrice(g.getDistance(), gr.getDistance(), nbrSommet);
        gr.setNbrSommets(g.getNbrSommets());
        ArrayList<String> Tour = new ArrayList<>();// La liste des sous Tours 

        ArrayList<Arc> ListSavings = new ArrayList<>();  // la liste des savings 

        double[][] Dist = new double[g.getNbrSommets()][g.getNbrSommets()];
        Utilitaire.recopierMatrice(g.getDistance(), Dist, g.getNbrSommets()); // R�cup�rer la matrice des distances

        // Arc pour r�cup�rer les savings
        Arc ar = null;

        // variable pour parcourir la list des savings 
        int i = 0;

        int vc; // Le sommet central 
        // g�n�rer un sommet centrale al�atoirement compris � [0 NbrSommet]
        Random r = new Random();
        vc = r.nextInt(g.getNbrSommets());
//        System.out.println("Sommet centrale = " + vc);
        // Rajouter le sommet centrale au tour 
        Tour.add("-" + vc + "-");
        // Calculer les Savings :
        ListSavings = CalculSavings(Dist, g.getNbrSommets(), vc);
//        System.out.println("t1");
        // Tableau des sous-cycle entre le sommet centrale et les autres sommets
        int[] sousTab = new int[g.getNbrSommets()];

        // Initailiser le tableau des sous cycle sousTab[i] � 2 repr�sentant le nombre de lien entre le sommet "i" et le sommet centrale "vc"
        for (int l = 0; l < sousTab.length; l++) {
            sousTab[l] = 2;
        }

        // Inhiber la case sousTab[Vc]
        sousTab[vc] = 0;

        while (i < ListSavings.size()) { // On parcourt tous les �l�ment de la list
            ar = ListSavings.get(i);
            i++;

            String T, T1, T2; // variable pour les sous-Tour

            if (sousTab[ar.getSommet1()] != 0 && sousTab[ar.getSommet2()] != 0) { // il reste des arretes � remplacer pour les deux sommets
                // Remplacer (vc-som1) et (vc-som2) par (som1-som2)
                T = Utilitaire.verif2SommetsMemeTour(Tour, ar.getSommet1(), ar.getSommet2());

                if (T == null) { // Si som1 ou som2 ne sont pas d�j� dans le tour
                    T1 = Utilitaire.rechercherTourSommet(Tour, ar.getSommet1()); // rechercher le tour ou figure som1
                    T2 = Utilitaire.rechercherTourSommet(Tour, ar.getSommet2()); // rechercher le tour ou figure som2 

                    if ((T1 == null) && (T2 == null)) { // les deux sommet ne figure dans aucun Tour
                        Tour.add(new String("-" + vc + "-" + ar.getSommet1() + "-" + ar.getSommet2()) + "-");
//                        System.out.println("-" + vc + "-" + ar.getSommet1() + "-" + ar.getSommet2() + "-");
                    } else if ((T1 != null) && (T2 == null)) { // Rajouter sommet2 au tour T1
//                        System.out.println(" T1 avant " + T1);
                        Tour.remove(T1); // On enl�ve l'ancien tour T1 
                        T1 = T1.concat("-" + ar.getSommet2() + "-");
                        Tour.add(T1);
//                        System.out.println(" T1 apr�s " + T1);
                    } else if ((T1 == null) && (T2 != null)) { // Rajouter sommet1 au tour T2
//                        System.out.println(" T2 avant " + T2);
                        Tour.remove(T2); // On enl�ve l'ancien tour T2
                        T2 = T2.concat("-" + ar.getSommet1() + "-");
                        Tour.add(T2);
//                        System.out.println(" T2 apres " + T2);
                    } else if ((T1 != null) && (T2 != null)) { // Fusionner les deux Tour
//                        System.out.println(" T1 avant " + T1 + "T2 avant " + T2);
                        Tour.remove(T2); // On enl�ve l'ancien tour T2
                        Tour.remove(T1); // On en,l�ve l'ancien tour T1
                        T1 = T1.concat("" + T2);
//                        System.out.println(" fusion  " + T1);
                        Tour.add(T1);
                    }
                    sousTab[ar.getSommet1()] = sousTab[ar.getSommet1()] - 1;
                    sousTab[ar.getSommet2()] = sousTab[ar.getSommet2()] - 1;

                    // Rajouter l'arc (som1 som2) au chemin 
                    ar.setDist(Dist[ar.getSommet1()][ar.getSommet2()]); // Remettre la valeur de distance r�elle entre les 2 sommets
                    this.chemin.getArcs().add(ar);
                    // Mettre � jour la valeur du chemin
                    this.chemin.setEval(this.chemin.getEval() + ar.getDist());
                }
            }
        }

        int j = 0;
        while (j < sousTab.length) {
            if (sousTab[j] > 0) { // l'arrete vc-j n'as pas �t� enlev�e --> il faut la rajouter dans le chemin final
                this.chemin.getArcs().add(new Arc(vc, j, g.getValDistance(vc, j)));
                // M�j le cout du chemin 
                this.chemin.setEval(this.chemin.getEval() + g.getValDistance(vc, j));
//                System.out.println(" arretes rajout�es vi = " + vc + "-- vj= " + j);
            }
            j++;
        }
//        Iterator<Arc> it = this.chemin.getArcs().iterator();
//        Arc arr;
//        while (it.hasNext()) {
//            arr = it.next();
//            System.out.println(" vi = " + arr.getSommet1() + "-- vj= " + arr.getSommet2() + " dist = " + arr.getDist());
//        }

//        System.out.println(" Chemin finale est : " + this.chemin.chemin_finale_Symetric(0, g.getNbrSommets()));
//        System.out.println(" le cout du chemin est : " + this.chemin.getEval());
        return this.chemin;
    }

    public void remplirDessin() {
        //remplir la liste des arcs pour le dessin
        Arc tmp = null;
        tabDessin.clear();
        String chem = this.chemin.chemin_finale_Symetric(0, this.nbrSommet);
        Chemin ch = Utilitaire.StringToChemin(gr, chem);
        this.chemin.getArcs().clear();
        for (Arc arc : ch.getArcs()) {
            tmp = new Arc(arc.getSommet1(), arc.getSommet2(), arc.getDist());
            this.chemin.getArcs().add(new Arc(arc.getSommet1(), arc.getSommet2(), arc.getDist()));
            tabDessin.add(new ArcDessin(tmp)); // Pour le dessin
        }
    }

    public Chemin getChemin() {
        return chemin;
    }
    
    
}
