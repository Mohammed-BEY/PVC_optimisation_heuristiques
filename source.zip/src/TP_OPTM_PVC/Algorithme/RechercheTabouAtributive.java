package TP_OPTM_PVC.Algorithme;

import TP_OPTM_PVC.Model.Arc;
import TP_OPTM_PVC.IHM.ArcDessin;
import TP_OPTM_PVC.Model.Chemin;
import TP_OPTM_PVC.Model.Graphe;
import TP_OPTM_PVC.Mouvement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

/**
 *
 * @author LOUNIS
 */
public class RechercheTabouAtributive {

    private int tailleListeTabou;
    private int maxIterations;
    private int TTL_Tabou;
    private ArrayList<Mouvement> listeTabou = new ArrayList<>();//Creer la liste Tabou qui contient les chemins réçament visitésF
    private ArrayList<Mouvement> listeVoisinageSolution = new ArrayList<>();//Voisinage d'une solution
    public ArrayList tabDessin = new ArrayList();// contient les �tapes du dessin
    Chemin chemin = new Chemin(); // La liste ddes arcs dans le chemin 

    public Chemin rechTabou(Graphe graphe) {//Parametres de recherche Tabou

        ProcheVoisin pprochevoisin = new ProcheVoisin();//Déterminer la solution initiale
        // Générer une ville de depart aléatoirement parmis les villes du graphe
        Random ran = new Random();
        int sommetInitial = ran.nextInt(graphe.getNbrSommets());
        Chemin cheminInitial = pprochevoisin.PProche_Voisin(graphe, sommetInitial);  // Calculer le chemin avec l'heuristique du plus proche voisin 

        Chemin solutionCourante = new Chemin(); //Obtenir les arcs du chemin courant a partir de chemin initial
        for (Arc arc : cheminInitial.getArcs()) {
            solutionCourante.getArcs().add(new Arc(arc.getSommet1(), arc.getSommet2(), graphe.distanceAB(arc.getSommet1(), arc.getSommet2())));
        }

        solutionCourante.setEval(cheminInitial.getEval());

        Chemin cheminPermutation2_OPT = new Chemin();

        Chemin meilleurSolTmp = new Chemin();
        for (Arc arc : cheminInitial.getArcs()) {
            meilleurSolTmp.getArcs().add(new Arc(arc.getSommet1(), arc.getSommet2(), graphe.distanceAB(arc.getSommet1(), arc.getSommet2())));
        }
        meilleurSolTmp.setEval(cheminInitial.getEval());

        int nbrIterations = 0;
        int sommetI, sommetJ, sommetK, sommetL;
        int nbArcs = solutionCourante.getArcs().size();
        double couTmp;
        double coutPermut;
        //Déclaration des mouvements temporaires
        Mouvement mvntMeilleurVoisin = new Mouvement();
        int indiceMeilleurMvnt = 0;
        boolean iterationLocal = true;
        do {
//            solutionCourante.AfficherChemin();
            listeVoisinageSolution.clear();
            //Trouver le voisinage d'une solution
            for (int i = 0; i < nbArcs - 2; i++) {//parcourir la liste des sommets
                for (int j = i + 2; j < nbArcs; j++) {
                    sommetI = solutionCourante.getArcs().get(i).getSommet1();
                    sommetJ = solutionCourante.getArcs().get(i).getSommet2();
                    sommetK = solutionCourante.getArcs().get((j)).getSommet1();
                    sommetL = solutionCourante.getArcs().get((j)).getSommet2();
                    if (sommetI != sommetL) {
                        //on quitte quand il n'y a plus d'amélioration possible du chemin
                        //Faire les permutations pour comparer avec la meilleure solution
                        cheminPermutation2_OPT.getArcs().clear();
                        for (Arc arc : solutionCourante.getArcs()) {
                            cheminPermutation2_OPT.getArcs().add(new Arc(arc.getSommet1(), arc.getSommet2(), arc.getDist()));
                        }
//                        cheminPermutation2_OPT.AfficherChemin();
                        //Suavegarder la valeur de l'evaluation
                        cheminPermutation2_OPT.setEval(solutionCourante.getEval());

                        //construire un nouveau chemin meilleur que le précédent
                        coutPermut = cheminPermutation2_OPT.getArcs().get(i).getDist() + cheminPermutation2_OPT.getArcs().get(j).getDist();

                        cheminPermutation2_OPT.getArcs().get(i).setSommet2(sommetK);
                        cheminPermutation2_OPT.getArcs().get(i).setDist(graphe.distanceAB(sommetI, sommetK));
                        cheminPermutation2_OPT.getArcs().get(j).setSommet1(sommetJ);
                        cheminPermutation2_OPT.getArcs().get(j).setDist(graphe.distanceAB(sommetJ, sommetL));

                        coutPermut = cheminPermutation2_OPT.getEval() - coutPermut;
                        cheminPermutation2_OPT.setEval(coutPermut);
                        // Les nouvelles distance aprés permutation 
                        coutPermut = cheminPermutation2_OPT.getArcs().get(i).getDist() + cheminPermutation2_OPT.getArcs().get(j).getDist();
                        // Mà j le cout du chemin
                        coutPermut = cheminPermutation2_OPT.getEval() + coutPermut;
                        cheminPermutation2_OPT.setEval(coutPermut);
                        //réordonner les arcs
//                        cheminPermutation2_OPT.AfficherChemin();
//                        cptL = 1;
//                        for (int k = i + cptL; k <= j - cptL; k++) {
//                            cptSommet1 = cheminPermutation2_OPT.getArcs().get(k).getSommet1();
//                            cptSommet2 = cheminPermutation2_OPT.getArcs().get(k).getSommet2();
//                            cptDistance = cheminPermutation2_OPT.getArcs().get(k).getDist();
//                            cheminPermutation2_OPT.getArcs().get(k).setSommet1(cheminPermutation2_OPT.getArcs().get(j - cptL).getSommet1());
//                            cheminPermutation2_OPT.getArcs().get(k).setSommet2(cheminPermutation2_OPT.getArcs().get(j - cptL).getSommet2());
//                            cheminPermutation2_OPT.getArcs().get(k).setDist(cheminPermutation2_OPT.getArcs().get(j - cptL).getDist());
//
//                            cheminPermutation2_OPT.getArcs().get(j - cptL).setSommet1(cptSommet1);
//                            cheminPermutation2_OPT.getArcs().get(j - cptL).setSommet2(cptSommet2);
//                            cheminPermutation2_OPT.getArcs().get(j - cptL).setDist(cptDistance);
//                            cptL++;
//                        }
////                        cheminPermutation2_OPT.AfficherChemin();
//                        //ordonner les sommets des arcs
//                        for (int k = i + 1; k < j; k++) {
//                            tmpSommetPermutation = cheminPermutation2_OPT.getArcs().get(k).getSommet1();
//                            cheminPermutation2_OPT.getArcs().get(k).setSommet1(cheminPermutation2_OPT.getArcs().get(k).getSommet2());
//                            cheminPermutation2_OPT.getArcs().get(k).setSommet2(tmpSommetPermutation);
//                        }
//                        cheminPermutation2_OPT.AfficherChemin();
                        //calculer le cout du voisin apres la permutation
                        couTmp = cheminPermutation2_OPT.getEval();
                        //insérer le mouvement dans la liste des voisins
                        listeVoisinageSolution.add(new Mouvement(i, j, couTmp, TTL_Tabou));
                    }
                }
            }
            //ordonner la liste de voisinage selon l'aatribut Cout
            Collections.sort(listeVoisinageSolution);
            //Traitement du voisinage
//            meilleurSolTmp.AfficherChemin();
            indiceMeilleurMvnt = 0;
            iterationLocal = true;
            while (iterationLocal) {
                //récupérer le meilleur mouvement
                mvntMeilleurVoisin = listeVoisinageSolution.get(indiceMeilleurMvnt);
                //vérifier si le mouvement choisi appartient à la liste Tabou
                if (!listeTabou.contains((Mouvement) mvntMeilleurVoisin)) {//le mouvement n'apparient pas à la liste Tabou
                    iterationLocal = false;
                    //comparer le mouvement avec la meilleure solution
                    if (mvntMeilleurVoisin.getCoutApresPermutation() < meilleurSolTmp.getEval()) {//Si meilleur
                        //ajouter le mouvement a la liste tabou
                        if (listeTabou.size() == tailleListeTabou) {//on a atteint la taille maximale de la liste Tabou
                            listeTabou.remove(0);//on supprime le 1er élément
                        }
                        listeTabou.add(mvntMeilleurVoisin);
                        //Mise à jour de la meilleure solution courante
                        //Copier le contenu de la solution courante dans la meilleure solution
                        for (int i = 0; i < solutionCourante.getArcs().size(); i++) {
                            meilleurSolTmp.getArcs().get(i).setSommet1(solutionCourante.getArcs().get(i).getSommet1());
                            meilleurSolTmp.getArcs().get(i).setSommet2(solutionCourante.getArcs().get(i).getSommet2());
                            meilleurSolTmp.getArcs().get(i).setDist(solutionCourante.getArcs().get(i).getDist());
                        }
                        //effectuer la permutation 2-OPt
                        permuter2_OPT(meilleurSolTmp, mvntMeilleurVoisin.getArcIJ(), mvntMeilleurVoisin.getArcKL(), graphe, mvntMeilleurVoisin.getCoutApresPermutation());
                        //Mise à jour de la solutin courante pour la prochaine itération
                        for (int i = 0; i < meilleurSolTmp.getArcs().size(); i++) {
                            solutionCourante.getArcs().get(i).setSommet1(meilleurSolTmp.getArcs().get(i).getSommet1());
                            solutionCourante.getArcs().get(i).setSommet2(meilleurSolTmp.getArcs().get(i).getSommet2());
                            solutionCourante.getArcs().get(i).setDist(meilleurSolTmp.getArcs().get(i).getDist());
                        }
                        solutionCourante.setEval(meilleurSolTmp.getEval());
                    } else {//Mise à jour de 
                        //Mise à jour de la solutin courante pour la prochaine itération
                        permuter2_OPT(solutionCourante, mvntMeilleurVoisin.getArcIJ(), mvntMeilleurVoisin.getArcKL(), graphe, mvntMeilleurVoisin.getCoutApresPermutation());
                    }
                    //Décrémentation des TTLs des éléments de la liste Tabou
                    for (int i = 0; i < listeTabou.size(); i++) {
                        int tmpTTL;
                        tmpTTL = listeTabou.get(i).getTTL_Tabou() - 1;
                        if (tmpTTL == 0) {
                            listeTabou.remove(i);
                        } else {
                            listeTabou.get(i).setTTL_Tabou(tmpTTL);//supprimer le mouvement de la liste tabou
                        }
                    }
//                    solutionCourante.AfficherChemin();

                } else//si le mouvement appartient à la liste Tabou
                //vérifier le critére d'aspiration
                 if (mvntMeilleurVoisin.getCoutApresPermutation() < meilleurSolTmp.getEval()) {//on a ontenu un meilleur cout
                        iterationLocal = false;
                        //réinitialiser la tenure du mouvement
                        mvntMeilleurVoisin.setTTL_Tabou(TTL_Tabou);
                        //Mise à jour de la meilleure solution
                        //Copier le contenu de la solution courante dans la meilleure solution
                        for (int i = 0; i < solutionCourante.getArcs().size(); i++) {
                            meilleurSolTmp.getArcs().get(i).setSommet1(solutionCourante.getArcs().get(i).getSommet1());
                            meilleurSolTmp.getArcs().get(i).setSommet2(solutionCourante.getArcs().get(i).getSommet2());
                            meilleurSolTmp.getArcs().get(i).setDist(solutionCourante.getArcs().get(i).getDist());
                        }
                        //effectuer la permutation 2-OPt
                        permuter2_OPT(meilleurSolTmp, mvntMeilleurVoisin.getArcIJ(), mvntMeilleurVoisin.getArcKL(), graphe, mvntMeilleurVoisin.getCoutApresPermutation());
                        //Mise à jour de la solutin courante pour la prochaine itération
                        for (int i = 0; i < meilleurSolTmp.getArcs().size(); i++) {
                            solutionCourante.getArcs().get(i).setSommet1(meilleurSolTmp.getArcs().get(i).getSommet1());
                            solutionCourante.getArcs().get(i).setSommet2(meilleurSolTmp.getArcs().get(i).getSommet2());
                            solutionCourante.getArcs().get(i).setDist(meilleurSolTmp.getArcs().get(i).getDist());
                        }
                        solutionCourante.setEval(meilleurSolTmp.getEval());
                    } else {//le critére d'aspiration n'est pas vérifié
                        //choisir un autre mouvement dans la liste des mouvements du voisinage 
                        indiceMeilleurMvnt++;
                        mvntMeilleurVoisin = listeVoisinageSolution.get(indiceMeilleurMvnt);
                    }
            }
            nbrIterations++;
        } while (nbrIterations < maxIterations);

//        System.out.println("\n======================La meilleure solution======================");
//
//        meilleurSolTmp.AfficherChemin();
//        System.out.println("Cout de la meilleur solution= " + meilleurSolTmp.coutSolution(meilleurSolTmp, graphe));
//
//        System.out.println("size Meilleur solution = " + meilleurSolTmp.getArcs().size());
        this.chemin = solutionCourante;
        return solutionCourante;
    }

    public int getTailleListeTabou() {
        return tailleListeTabou;
    }

    public void setTailleListeTabou(int tailleListeTabou) {
        this.tailleListeTabou = tailleListeTabou;
    }

    public int getMaxIterations() {
        return maxIterations;
    }

    public void setMaxIterations(int maxIterations) {
        this.maxIterations = maxIterations;
    }

    public int getTTL_Tabou() {
        return TTL_Tabou;
    }

    public void setTTL_Tabou(int TTL_Tabou) {
        this.TTL_Tabou = TTL_Tabou;
    }

    private void permuter2_OPT(Chemin solutionCourante, int arcIJ, int arcKL, Graphe graphe, double Newcout) {
        int sommetI = solutionCourante.getArcs().get(arcIJ).getSommet1(),
                sommetJ = solutionCourante.getArcs().get(arcIJ).getSommet2(),
                sommetK = solutionCourante.getArcs().get(arcKL).getSommet1(),
                sommetL = solutionCourante.getArcs().get(arcKL).getSommet2();

        solutionCourante.getArcs().get(arcIJ).setSommet2(sommetK);
        solutionCourante.getArcs().get(arcIJ).setDist(graphe.distanceAB(sommetI, sommetK));
        solutionCourante.getArcs().get(arcKL).setSommet1(sommetJ);
        solutionCourante.getArcs().get(arcKL).setDist(graphe.distanceAB(sommetJ, sommetL));
        //réordonner les arcs
        int cptL = 1, tmpSommetPermutation;
        int cptSommet1, cptSommet2;
        double cptDistance;
        for (int k = arcIJ + cptL; k <= arcKL - cptL; k++) {
            cptSommet1 = solutionCourante.getArcs().get(k).getSommet1();
            cptSommet2 = solutionCourante.getArcs().get(k).getSommet2();
            cptDistance = solutionCourante.getArcs().get(k).getDist();

            solutionCourante.getArcs().get(k).setSommet1(solutionCourante.getArcs().get(arcKL - cptL).getSommet1());
            solutionCourante.getArcs().get(k).setSommet2(solutionCourante.getArcs().get(arcKL - cptL).getSommet2());
            solutionCourante.getArcs().get(k).setDist(solutionCourante.getArcs().get(arcKL - cptL).getDist());

            solutionCourante.getArcs().get(arcKL - cptL).setSommet1(cptSommet1);
            solutionCourante.getArcs().get(arcKL - cptL).setSommet2(cptSommet2);
            solutionCourante.getArcs().get(arcKL - cptL).setDist(cptDistance);
            cptL++;
        }
        //ordonner les sommets des arcs
        for (int k = arcIJ + 1; k < arcKL; k++) {
            tmpSommetPermutation = solutionCourante.getArcs().get(k).getSommet1();
            solutionCourante.getArcs().get(k).setSommet1(solutionCourante.getArcs().get(k).getSommet2());
            solutionCourante.getArcs().get(k).setSommet2(tmpSommetPermutation);
        }
        solutionCourante.setEval(Newcout); // Sauvegarder le cout de la solution aprés permutation 
    }

    public void remplirDessin() {
        //remplir la liste des arcs pour le dessin
        Arc tmp = null;
        tabDessin.clear();
        for (Arc arc : this.chemin.getArcs()) {
            tmp = new Arc(arc.getSommet1(), arc.getSommet2(), arc.getDist());
            tabDessin.add(new ArcDessin(tmp)); // Pour le dessin
        }
    }
}
