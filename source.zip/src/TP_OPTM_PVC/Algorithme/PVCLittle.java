package TP_OPTM_PVC.Algorithme;

import TP_OPTM_PVC.Model.Arc;
import TP_OPTM_PVC.Model.Chemin;
import TP_OPTM_PVC.Model.Noeud;
import TP_OPTM_PVC.Utilitaire;
import java.util.ArrayList;

import java.util.Stack;

public class PVCLittle {

    private double evaluMin; // Repr�sente la borne INF de l'�valuation de la solution optimale
    private double evaluMax; // Repr�sente la borne SUP de l'�valuation de la solution optimale

    private ArrayList<Chemin> MeilleurChemin; // Repr�sente  la liste des slutions otpimales trouv�es

    public PVCLittle() {
        super();
        this.evaluMin = 0;
        this.evaluMax = Double.POSITIVE_INFINITY;
        this.MeilleurChemin = new ArrayList<>();
    }

    /**
     * *
     *
     * @param N : le noeud en cours dans la recherche
     *
     * @return : l'evaluation du noeud en cours
     */
    public double reductionCout(Noeud N) {

        double D1s = 0, D2s = 0, val = 0;
        double DiS = 0, DjS = 0;
        int tail = N.getGraphe().getNbrSommets();

        int i = 0, j = 0;
        ArrayList<Integer> F = new ArrayList<>();
        ArrayList<Integer> D = new ArrayList<>();
        // On r�cup�re la liste des noeuds qui sont source et ceux qui sont destination  dans PS

        N.getDebut_Fin_PS(D, F);

        while (i < tail) {
            if (!D.contains(i)) {
                DiS = Utilitaire.calculMin(N.getGraphe().getDistance(), i, -1, tail); // on calcul le minimum selon les lignes
                D1s = D1s + DiS;
                // System.out.println(" minimal de la ligne "+DiS);
                for (int jj = 0; jj < N.getGraphe().getNbrSommets(); jj++) {
                    if (N.getGraphe().getValDistance(i, jj) != Double.POSITIVE_INFINITY) {
                        val = N.getGraphe().getValDistance(i, jj) - DiS;

                        N.getGraphe().setValDistance(i, jj, val);
                    }
                }
            }
            i++;
        }

        while (j < tail) {
            if (!F.contains(j)) {
                DjS = Utilitaire.calculMin(N.getGraphe().getDistance(), -1, j, tail); // on calcul le minimuim selon les colones
                D2s = D2s + DjS;
                //	System.out.println(" minimal de la colone "+DjS);
                for (int ii = 0; ii < N.getGraphe().getNbrSommets(); ii++) {
                    if (N.getGraphe().getValDistance(ii, j) != Double.POSITIVE_INFINITY) {
                        val = N.getGraphe().getValDistance(ii, j) - DjS;

                        N.getGraphe().setValDistance(ii, j, val);
                    }
                }
            }
            j++;
        }

        F = null;
        D = null;
        return (D1s + D2s);
    }

    /**
     *
     * @param Noeud : Le noeud en cours de traitement
     *
     * @return l'arc qui a la valeur du regret la plus grande
     */
    public Arc PlusgrandRegret(Noeud N) {

        Arc arc_maxRegret = new Arc(); // l'arc qui a la valeur du regret la plus grande
        double reg = 0;
        double tmp = 0;
        for (int i = 0; i < N.getGraphe().getNbrSommets(); i++) {

            for (int j = 0; j < N.getGraphe().getNbrSommets(); j++) {

                if (N.getGraphe().getValDistance(i, j) == 0) {

                    tmp = N.getGraphe().getValDistance(i, j); // On sauvegarde l'ancienne valeur

                    N.getGraphe().setValDistance(i, j, Double.POSITIVE_INFINITY); // On marque la case comme inutilis�e pour eviter d'avoir le min toujour =0

                    reg = Utilitaire.calculMin(N.getGraphe().getDistance(), i, -1, N.getGraphe().getNbrSommets()) + Utilitaire.calculMin(N.getGraphe().getDistance(), -1, j, N.getGraphe().getNbrSommets());

                    N.getGraphe().setValDistance(i, j, tmp); // On ecrit l'ancienne valeur

                    //	System.out.print("R "+i+"-"+j+" "+reg+"\t");
                    if (reg > arc_maxRegret.getDist()) { // on a trouv� un regret plus grand
                        arc_maxRegret.setDist(reg);
                        arc_maxRegret.setSommet1(i);
                        arc_maxRegret.setSommet2(j);
                    }
                }

            }
        }
        return arc_maxRegret;
    }

    /**
     *
     * @param N : Noeud courant
     * @param S1 : Noeud d'inclusionr�sultant de la s�paration
     * @param S2 : Noeud d'exclusion r�sultatnt de la s�paration
     * @return : un boolean pour indiquer si on trouv� un circuit ou pas
     */
    public boolean separation_evaluation(Noeud N, Noeud S1, Noeud S2) {

        Arc arcPGR = PlusgrandRegret(N); // R�cup�rer l'arc de plus grand regret
        Arc arcEnlever = null;  // Arc qui doit etre enlev� de la mtrice des distances afin de ne pas construire un sous-cycle

        // System.out.println("Arc chosisit :" + arcPGR.getSommet1() + "*"+arcPGR.getSommet2() +"* reg "+arcPGR.getDist() );
        if (arcPGR.getDist() == Double.POSITIVE_INFINITY) { // Crit�re d'arr�t de la s�paration et de l'algos

            for (int i = 0; i < N.getGraphe().getNbrSommets(); i++) {

                for (int j = 0; j < N.getGraphe().getNbrSommets(); j++) {

                    if (N.getGraphe().getValDistance(i, j) == 0) {
                        Arc a = new Arc();
                        a.setSommet1(i);
                        a.setSommet2(j);
                        N.getPs().add(a);
                    }

                }
            }
            return true; // On a trouv� un circuit
        } else {
            // System.out.println("separation");
            /**
             * ************************* NOEUD S1
             * ******************************
             */
            // Ajouter les arc enpreint�s � PS et Non-emprient�s � Ms
            S1.getPs().addAll(N.getPs());
            S1.getPs().add(arcPGR);
            S1.getMs().addAll(N.getMs());

            // Recopier la liste des chemins dans S1
            S1.getChemin().addAll(N.getChemin());

            // Recopier la matrice de distance de S dans S1
            S1.CopierMatriceDistance(N.getGraphe().getDistance(), N.getGraphe().getNbrSommets());

            // Supprimer la ligne et la colone representant le nouveau arc rajout� � PS 
            S1.Supprime_Ligne(arcPGR.getSommet1(), arcPGR.getSommet2());

            // supprimer la case qui peut produire un sous-cycle en rajoutant l'arc (vi,vj) � l'ensemble de solution PS
            // arcEnlever = N.Construire_chemin(arcPGR.getSommet1(),arcPGR.getSommet2()) ; // On utilise l'ensemble Ps de l'ancien sommet N 
            // S1.Construire_Chemins_EnleverSous_Cycle(arcPGR.getSommet1(),arcPGR.getSommet2());
            S1.supprimer_cycle(arcPGR.getSommet1(), arcPGR.getSommet2(), S1.getGraphe().getNbrSommets());

            // Supprimer l'arc qui produit un sous-cycle
            S1.getGraphe().setValDistance(arcPGR.getSommet2(), arcPGR.getSommet1(), Double.POSITIVE_INFINITY);
            // System.out.println(" l'ARC ENLEVER est : " +arcEnlever.getSommet1() +" " + arcEnlever.getSommet2() + "\n");

            // Mettre � jour les autres arcs qui peuvent produire un sous-circuit
            // S1.MettreAjourDistance_PS();
            // Reduction de la matrice de sitance du Noeud S1
            /*System.out.println("****************** S1 ***************** \n");
			for(int i=0; i<S1.getGraphe().getNbrSommets(); i++){

				for(int j=0; j<S1.getGraphe().getNbrSommets(); j++){

					System.out.print( S1.getGraphe().getValDistance(i, j)+"\t");
				}
				System.out.println();
			}
             */
            double Ds1 = reductionCout(S1);
            //	System.out.println("****************** S1 ***************** \n");
            /*	for(int i=0; i<S1.getGraphe().getNbrSommets(); i++){

				for(int j=0; j<S1.getGraphe().getNbrSommets(); j++){

					System.out.print( S1.getGraphe().getValDistance(i, j)+"\t");
				}
				System.out.println();
			}*/

            // Calculer l'evaluation de "S1" = Evalution de "N" + "Ds"
            S1.setEvaluation(N.getEvaluation() + Ds1);
            //	System.out.println("evaluation de N " + N.getEvaluation() + " Valuer de DS est "+Ds1 + " evaluation de S1"+ S1.getEvaluation());

            /**
             * *****************************************************************
             */
            /**
             * ************************* NOEUD S2
             * ******************************
             */
            // Ajouter les arc enpreint�s � PS et Non-emprient�s � Ms
            S2.getMs().addAll(N.getMs());
            S2.getMs().add(arcPGR);
            S2.getPs().addAll(N.getPs());

            // Recopier la liste des chemins dans S1
            S2.getChemin().addAll(N.getChemin());

            // Recopier la matrice de distance de S dans S2
            // S2.getGraphe().setDistance(N.getGraphe().getDistance().clone());
            S2.CopierMatriceDistance(N.getGraphe().getDistance(), N.getGraphe().getNbrSommets());

            // Supprimer l'arc 'Vi' 'Vj' qui a le plus grand regret
            S2.getGraphe().setValDistance(arcPGR.getSommet1(), arcPGR.getSommet2(), Double.POSITIVE_INFINITY);

            // System.out.println("****************** S2 ***************** \n");
            /*		for(int i=0; i<S2.getGraphe().getNbrSommets(); i++){

				for(int j=0; j<S2.getGraphe().getNbrSommets(); j++){

					System.out.print( S2.getGraphe().getValDistance(i, j)+"\t");
				}
				System.out.println();
			}*/
            // Calculer l'evaluation de "S2" = Evalution de "N" + "Regret plus grand"
            S2.setEvaluation(N.getEvaluation() + arcPGR.getDist());

            //	System.out.println("evaluation de N " + N.getEvaluation() + " Valuer de regret est "+arcPGR.getDist() + " evaluation de S2 "+ S2.getEvaluation());
            /**
             * *****************************************************************
             */
            return false; // on a pas encore trouv� un circuit
        }
    }

    public long Branch_Bound(Noeud racine, int nbrSommets) {

        Stack<Noeud> pile = new Stack<>(); // La pile des noeuds non-visit�es

        boolean fin = false; // variable pour controller les it�rations de l'algorithme

        boolean trouv = false; // variable pour indiquer si on a trouv� un circuit ou pas

        boolean arret; // variable por rechercher le noued prometteur parmis ceux de la pile

        long startTime = System.currentTimeMillis();

        // Reduction du noeud racine + calcul de la borne INF
        this.evaluMin = reductionCout(racine);
        racine.setEvaluation(this.evaluMin);
        int i = 0;
        while (!fin) {

            // On cr�e un noeud � chaque it�ration
            Noeud S1 = new Noeud(nbrSommets); // Noeud d'inclusion 
            Noeud S2 = new Noeud(nbrSommets); // Noeud d'exclusion

            // On effectue la s�paration
            trouv = separation_evaluation(racine, S1, S2);

            // Marquer le noeud "visit�"
            racine.setVisite(true);

            // On met � jour la borne Sup si on a trouv� une solution 
            if (trouv) {
                this.evaluMax = racine.getEvaluation();
                // System.out.println("\n\nSolution optimale = "+this.evaluMax);
                MeilleurChemin.add(new Chemin(racine.getPs(), racine.getEvaluation()));

                if (pile.isEmpty()) { // La pile est vide
                    fin = true; // Fin de l'algo
                } else {

                    racine = pile.lastElement(); // On d�pile un noeud d'exclusion
                    pile.remove(racine);
                    arret = false;

                    while (racine.getEvaluation() > this.evaluMax && !arret) { // le noeud n'est pas prometteur 
                        // System.out.println("slt eval = "+racine.getEvaluation());
                        if (!pile.isEmpty()) {
                            racine = pile.lastElement(); // On d�pile un autre 
                            pile.remove(racine);
                        } else {
                            arret = true;
                        }
                    }
                    //	System.out.println("slt eval choisit = "+racine.getEvaluation());
                    /*					System.out.println("***********************************************");
					for(int ii=0; ii<5; ii++){

						for(int jj=0; jj<5; jj++){

							System.out.print( racine.getGraphe().getValDistance(ii, jj)+"\t");
						}
						System.out.println();
					}

					System.out.println("***********************************************");*/

                    if (arret) {
                        fin = true; // Il n'ya plus de noeud prometteur
                    } else {
                        reductionCout(racine); // On r�duit la matrice des distance du neoud exclusion

                        /*System.out.println("***********************************************");
						for(int ii=0; ii<racine.getGraphe().getNbrSommets(); ii++){

							for(int jj=0; jj<racine.getGraphe().getNbrSommets(); jj++){

								System.out.print( racine.getGraphe().getValDistance(ii, jj)+"\t");
							}
							System.out.println();
						}

						System.out.println("***********************************************");*/
                    }

                }
            } else { // Sinon on continue le parcourt 

                if (S2.getEvaluation() >= this.evaluMin && S2.getEvaluation() <= this.evaluMax) { // si le noeud est valide
                    pile.add(S2); // On empile les noeuds d'exclusion
                    //	System.out.println(" \t\t Taille "+pile.size());
                }

                if (S1.getEvaluation() >= this.evaluMin && S1.getEvaluation() <= this.evaluMax) {
                    // On effectue un parcourt en profondeur pour trouver la borne Sup (solution ) rapidement
                    racine = S1;

                } else if (pile.isEmpty()) { // La pile est vide
                    fin = true; // Fin de l'algo
                } else {
                    racine = pile.lastElement(); // On d�pile un noeud d'exclusion
                    pile.remove(racine);
                    arret = false;

                    while (racine.getEvaluation() > this.evaluMax && !arret) { // le noeud n'est pas prometteur 
                        // .out.println("slt eval = "+racine.getEvaluation());
                        if (!pile.isEmpty()) {
                            racine = pile.lastElement(); // On d�pile un autre 
                            pile.remove(racine);
                        } else {
                            arret = true;
                        }
                    }
                    // System.out.println("slt eval choisit = "+racine.getEvaluation());

                    if (arret) {
                        fin = true; // Il n'ya plus de noeud prometteur
                    } else {
                        reductionCout(racine); // On r�duit la matrice des distance du neoud exclusion
                    }
                }
            }

            // System.out.println("Evaluation courante S1= "+S1.getEvaluation()+" S2="+S2.getEvaluation());
            if (racine == null) {
                fin = true; // Si il n' ya pas d'autre Noeuds prometteur --> On s'arrete 
            }
        }

        long endTime = System.currentTimeMillis();
        return (endTime - startTime);
    }

    /**
     * Elle permet de construire un chemin � partir d'un sommet donn�e
     */
    /**
     * @return the evaluMin
     */
    public double getEvaluMin() {
        return evaluMin;
    }

    /**
     * @param evaluMin the evaluMin to set
     */
    public void setEvaluMin(double evaluMin) {
        this.evaluMin = evaluMin;
    }

    /**
     * @return the evaluMax
     */
    public double getEvaluMax() {
        return evaluMax;
    }

    /**
     * @param evaluMax the evaluMax to set
     */
    public void setEvaluMax(double evaluMax) {
        this.evaluMax = evaluMax;
    }

    /**
     * @return the meilleurChemin
     */
    public ArrayList<Chemin> getMeilleurChemin() {
        return MeilleurChemin;
    }

    /**
     * @param meilleurChemin the meilleurChemin to set
     */
    public void setMeilleurChemin(ArrayList<Chemin> meilleurChemin) {
        MeilleurChemin = meilleurChemin;
    }

}
