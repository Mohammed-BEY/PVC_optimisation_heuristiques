package TP_OPTM_PVC.Algorithme;

import TP_OPTM_PVC.Model.Arc;
import TP_OPTM_PVC.IHM.ArcDessin;
import TP_OPTM_PVC.Model.Chemin;
import TP_OPTM_PVC.Model.Graphe;
import TP_OPTM_PVC.Utilitaire;
import java.util.ArrayList;
import java.util.Iterator;

public class ProcheVoisin {

    public ArrayList tabDessin;// contient les �tapes du dessin
    private ArrayList<Arc> chemin; // La liste ddes arcs dans le chemin 

    public ProcheVoisin() {
        super();
        chemin = new ArrayList<>();
        tabDessin = new ArrayList();
    }

    /**
     *
     * @param g : le graphe du probl�me � r�soudre Elle permet de r�soudre le
     * probl�me de PVC en utilisant la m�thode
     */
    public Chemin PProche_Voisin(Graphe g, int sommetDepart) {
        Chemin cheminHam = new Chemin();
        ArrayList<Integer> sommetVisite = new ArrayList<>(); // La liste de sommets visit�s 

        double[][] Dist = new double[g.getNbrSommets()][g.getNbrSommets()];
        Utilitaire.recopierMatrice(g.getDistance(), Dist, g.getNbrSommets()); // R�cup�rer la matrice des distances

        int vi; // Le sommet en cours
        int vj = 0; // Le sommet suivant dans le chemin
        int nbrSommVisite = 0; // Le nombre de sommets visit�s 

        vi = sommetDepart; // On initialise le sommet d�part;
        Utilitaire.supprimer_colonne(Dist, vi, g.getNbrSommets()); // supprimer la colonne 'vi'

        while (nbrSommVisite < g.getNbrSommets() - 1) { // Tant qu'il existe enccore des sommets � visiter
            // On garde le dernier sommets � la fin car le traitement est diff�rent
            vj = Utilitaire.calculIndiceMin(Dist, vi, -1, g.getNbrSommets()); // On calcul l'indice (la ville) tq d(vi ,vj) est minimale
//            System.out.println(" vi = " + vi + "-- vj= " + vj + " dist = " + Dist[vi][vj]);

            this.chemin.add(new Arc(vi, vj, Dist[vi][vj])); // Rajouter l'arc au chemin 

            Utilitaire.supprimer_ligne(Dist, vi, g.getNbrSommets()); // supprimer la ligne courante
            Utilitaire.supprimer_colonne(Dist, vj, g.getNbrSommets()); // supprimer la colonne rajout�e pour �viter les cyscles
            sommetVisite.add(vi); // rajouter le sommet vj � la liste des sommets visit�s

            vi = vj;
            nbrSommVisite++; // on incr�mente le nombre de sommet visit�
        }

        // Rechercher le dernier sommet (celui qui n'est pas encore visit�)
        int i = 0;
        boolean trouve = false;
        while (!trouve && i < g.getNbrSommets()) {

            if (!sommetVisite.contains(i)) { // Le sommet n'est pas visit�
                trouve = true;
            }
            i++;
        }
        i = i - 1; // R�cup�rer la ville non encore visit�
        if (trouve) { // Si on a trouv� le dernier sommet non visit�
            this.chemin.add(new Arc(i, sommetDepart, g.getValDistance(i, sommetDepart))); // Rajouter l'arc au chemin 
        }
        cheminHam.setArcs(chemin);
        //remplir la liste des arcs pour le dessin
        Arc tmp = null;
        tabDessin.clear();
        for (Arc arc : cheminHam.getArcs()) {
            tmp = new Arc(arc.getSommet1(), arc.getSommet2(), arc.getDist());
            tabDessin.add(new ArcDessin(tmp)); // Pour le dessin
        }
        return cheminHam;
    }

    public ArrayList<Arc> getChemin() {
        return chemin;
    }
}
