/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TP_OPTM_PVC.Algorithme;

import TP_OPTM_PVC.Model.Arc;
import TP_OPTM_PVC.IHM.ArcDessin;
import TP_OPTM_PVC.Model.Chemin;
import TP_OPTM_PVC.Model.Graphe;
import TP_OPTM_PVC.Utilitaire;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class AG {

    double Dist[][];
    int population_ini[][];
    int sommetVisite[];
    int Tour[];
    int indi[];
    double matrice_dis[][];
    double tab_cout[];
    int tab_indid_tri[];
    int nbIndividu, nbVilles, nb_genera, sele;
    double proba_coise, proba_mut;
    int fils[][];
    int nb_fils;
    int Ville[];
    public String[][] dataAGsolution;
    public ArrayList tabDessin;// contient les �tapes du dessin

    public AG() {
        tabDessin = new ArrayList();
        population_ini = new int[10000][5000];
        matrice_dis = new double[10000][5000];
        tab_cout = new double[10000];
        tab_indid_tri = new int[10000];
        fils = new int[10000][5000];
        Ville = new int[5000];
    }

    public Chemin LancerAG() {
        int IndMeilleurIndiv = 0;
        int tabMeilleurIndiv[] = new int[nbVilles];
        if (sele == 3) { // On execute l'algorithme avec la stratégie de séléction aléatoire
            IndMeilleurIndiv = algo_gen_alea();
        } else {  // On execute l'algorithme avec la stratégie de séléction aléatoire-ellitiste ou ellitiste
            IndMeilleurIndiv = algo_gen();
        }

        for (int j = 0; j < nbVilles; j++) {
            tabMeilleurIndiv[j] = population_ini[IndMeilleurIndiv][j];
        }
        Graphe g = new Graphe(nbVilles);
        g.setDistance(matrice_dis);
        Chemin ch = Utilitaire.tableauToChemin(g, tabMeilleurIndiv);
//        ch.AfficherChemin();
        //remplir la liste des arcs pour le dessin
        Arc tmp = null;
        tabDessin.clear();
        for (Arc arc : ch.getArcs()) {
            tmp = new Arc(arc.getSommet1(), arc.getSommet2(), arc.getDist());
            tabDessin.add(new ArcDessin(tmp)); // Pour le dessin
        }
        ch.setEval(tab_cout[0]);
        return ch;
    }

    void creerIndividus()//, long *population)
    {
        int i, j, tempVerif;

        long verifDoublon[][] = new long[nbIndividu][nbVilles];

        for (i = 0; i < nbIndividu; i++) {
            for (j = 0; j < nbVilles; j++) {
                verifDoublon[i][j] = 0;
            }
        }

        for (i = 0; i < nbIndividu; i++) {
            for (j = 0; j < nbVilles; j++) {
                do {

                    tempVerif = tirage(nbVilles);
                } while (verifDoublon[i][tempVerif] != 0);
                population_ini[i][j] = tempVerif;

                verifDoublon[i][tempVerif] = 1;
            }
        }

        for (i = 0; i < nbIndividu; i++) {
            for (j = 0; j < nbVilles; j++) {
                population_ini[i][j] = population_ini[i][j] + 1;

            }
        }

    }

    void calcul_cout() {
        double cout_c = 0;

        int i, j, v1, v2 = 0, s;
        for (i = 0; i < nbIndividu; i++) {
            tab_cout[i] = 0;
            for (j = 0; j < nbVilles - 1; j++) {
                v1 = population_ini[i][j];
                v2 = population_ini[i][j + 1];
                tab_cout[i] = tab_cout[i] + matrice_dis[v1 - 1][v2 - 1];

            }
            tab_cout[i] = tab_cout[i] + matrice_dis[v2 - 1][population_ini[i][0] - 1];
        }

    }

    void classement() {
        int i, j, temp2;
        double temp = 0;
        for (i = 0; i < nbIndividu; i++) {
            tab_indid_tri[i] = i;
        }
        for (i = 0; i < nbIndividu; i++) {
            for (j = i + 1; j < nbIndividu; j++) {
                if (tab_cout[j] < tab_cout[i]) {
                    temp = tab_cout[i];
                    tab_cout[i] = tab_cout[j];
                    tab_cout[j] = temp;
                    temp2 = tab_indid_tri[i];
                    tab_indid_tri[i] = tab_indid_tri[j];
                    tab_indid_tri[j] = temp2;
                }
            }
        }
    }

    void init_fils(int indice) {
        int i, j;
        for (i = 0; i < nbVilles; i++) {
            fils[indice][i] = 0;
        }
    }

    int existe(int v, int indice) {
        int i = 0, exis = 0;
        while (i < nbVilles && exis == 0) {
            if (fils[indice][i] == v) {
                exis = 1;
            }
            i++;
        }
        return exis;
    }

    void croisement(int p1, int p2) {
        init_fils(nb_fils);
        init_fils(nb_fils + 1);
        int res;
        int point1 = nbVilles / 3, point2 = 2 * (nbVilles / 3);
        int i;
        for (i = point1; i < point2; i++) {
            fils[nb_fils][i] = population_ini[p1][i];

            fils[nb_fils + 1][i] = population_ini[p2][i];
        }
        int i1 = point2, i2 = point2;
        for (i = point2; i < nbVilles; i++) {
            res = existe(population_ini[p2][i], nb_fils);
            if (res == 0) {
                fils[nb_fils][i1] = population_ini[p2][i];
                i1 = (i1 + 1) % (nbVilles);
            }

            res = existe(population_ini[p1][i], nb_fils + 1);
            if (res == 0) {
                fils[nb_fils + 1][i2] = population_ini[p1][i];
                i2 = (i2 + 1) % (nbVilles);
            }
        }

        for (i = 0; i < point2; i++) {
            res = existe(population_ini[p2][i], nb_fils);
            if (res == 0) {
                fils[nb_fils][i1] = population_ini[p2][i];
                i1 = (i1 + 1) % (nbVilles);
            }

            res = existe(population_ini[p1][i], nb_fils + 1);
            if (res == 0) {
                fils[nb_fils + 1][i2] = population_ini[p1][i];
                i2 = (i2 + 1) % (nbVilles);
            }
        }
        nb_fils = nb_fils + 2;
    }

    void mutation_1(int indice) {
        int v1, v2, v3, v4, v5, v6;
        double cout1 = 0, cout2 = 0;
        int fin = 0;
        while (fin == 0) {
            v1 = tirage(nbVilles);
            /*while (v1==0)
  {
    v1=tirage(nbVilles);
  }*/
            v2 = tirage(nbVilles);
            while (v1 == v2) {
                v2 = tirage(nbVilles);
            }
            int in1, in2;
            in1 = v1;
            in2 = v2;
            v1 = fils[indice][v1];
            v2 = fils[indice][in1 - 1];
            if (v1 != nbVilles - 1) {
                v3 = fils[indice][in1 + 1];
            } else {
                v3 = fils[indice][0];
            }
            v4 = fils[indice][in2 - 1];
            v5 = fils[indice][in2];
            if (v2 != nbVilles - 1) {
                v6 = fils[indice][in2 + 1];
            } else {
                v6 = fils[indice][0];
            }
            cout1 = matrice_dis[v2][v1] + matrice_dis[v1][v3] + matrice_dis[v4][v5] + matrice_dis[v5][v6];
            cout2 = matrice_dis[v2][v5] + matrice_dis[v5][v3] + matrice_dis[v4][v1] + matrice_dis[v1][v6];
            if (cout2 < cout1) {
                fils[indice][in1] = v5;
                fils[indice][in2] = v1;
                fin = 1;
            }
        }
    }

    double proba() {
        double n1 = tirage(1024);
        double n2;
        n2 = n1 / 1024;
        return n2;
    }

    void parent_fils(int indice) {
        int i;
        for (i = 0; i < nbVilles; i++) {
            fils[nb_fils][i] = population_ini[indice][i];
        }
        nb_fils++;
    }

    int exi(int tab[], int v) {
        int ex = 0, i = 0;
        while (i < nbIndividu && ex == 0) {
            if (tab[i] == v) {
                ex = 1;
            }
            i++;
        }
        return ex;
    }

    void croisement_g() {
        int exist[] = new int[nbIndividu];
        int in1, in2, i, r = 0;
        double p;
        for (i = 0; i < nbIndividu; i++) {
            exist[i] = 0;
        }

        int o;
        for (o = 0; o < nbIndividu / 4; o++) {

            in1 = tirage(nbIndividu / 2 + 1);
            exist[r] = in1;
            r++;
            in2 = tirage(nbIndividu / 2 + 1);
            int res = exi(exist, in2);
            exist[r] = in2;
            r++;

            in1 = tab_indid_tri[in1];
            in2 = tab_indid_tri[in2];
            p = proba();
            if (p <= proba_coise) {
                croisement(in1, in2);
            } else {
                parent_fils(in1);
                parent_fils(in2);
            }

        }

    }

    void mutation_g() {
        int i;
        double p = proba();
        for (i = 0; i < nbIndividu / 2; i++) {
            if (p < proba_mut) {
                mutation_1(i);
            }
        }
    }

    void migration() {
        int i, j, c;

        c = tab_indid_tri[0];
        for (j = 0; j < nbVilles; j++) {
            population_ini[0][j] = population_ini[c][j];
        }

        for (i = 1; i < nb_fils; i++) {
            for (j = 0; j < nbVilles; j++) {
                population_ini[i][j] = fils[i][j];
            }
        }
        for (i = nb_fils; i < nbIndividu; i++) {
            for (j = 0; j < nbVilles; j++) {
                population_ini[i][j] = population_ini[i][j];

            }

        }
        nb_fils = 0;
    }

    void matrice_dis_manu() {
        int v, o;
        double h;
        Scanner sc = new Scanner(System.in);
        for (v = 0; v < nbVilles; v++) {
            for (o = 0; o < nbVilles; o++) {
                if (o != v) {
                    System.out.print("distance[" + v + 1 + "][" + o + 1 + "] : ");
                    h = sc.nextDouble();
                    matrice_dis[v][o] = h;
                    System.out.println(h);
                } else {
                    matrice_dis[v][o] = 0;
                }
            }
            System.out.println("\n");
        }
    }

    int algo_gen() {
        nb_fils = 0;
        int i = 0, l;

        int indice_meill = 0;
        double c1 = 0;
        attrapeVille(nbVilles, Ville);
        creerIndividus(); //1 ville de depart  7:nbindividus
//        if (choix == 1) {
//            matrice_dis_alea(nbVilles);  //5 nb_ville
//
//        } else if (choix == 2) {
//            matrice_dis_manu();
//        } else {
//            LireXML c = new LireXML();
//            matrice_dis = c.matFromXML("a280.xml").getDistance();
//        }
        //       int m;
        int p = nbIndividu / 3;
        GenererINdividuHeuristique(p);
        for (i = 0; i < nb_genera; i++) {
            calcul_cout();
            if (i > 0) {
                c1 = tab_cout[0];
            }
            classement();
            indice_meill = tab_indid_tri[0];
            if (c1 != tab_cout[0]) {
                System.out.println("\n la génération: " + (i + 1));
                System.out.println("\n le cout de la meilleure solution: \n" + tab_cout[0]);
                System.out.println("la solution: \n");
                for (l = 0; l < nbVilles; l++) {
                    System.out.print("|" + population_ini[indice_meill][l] + "|");
                }
                System.out.println("\n\n");
            }

            croisement_g();
            if (sele == 1) {
                migration();
            } else if (sele == 2) {
                migration_eliteste();
            }
        }
        calcul_cout();
        classement();

        return indice_meill;
    }

    void attrapeVille(long nbVilles, int VILLE[]) {
        int i;
        for (i = 0; i < nbVilles; i++) {
            (VILLE[i]) = i + 1;
        }
    }

    int graineRandom = 0;

    int tirage(int valeurMax) {
        int resultat;
        //On fabrique une nouvelle graine pour le tirage au sort
        //On soustrait 1 à nbVilles car le tableu démarre à 0.
        Random rand = new Random();
        resultat = rand.nextInt(valeurMax);
        return resultat;
    }

    void matrice_dis_alea(int nb_Villes) {
        int i, j;
        double n2, n1;
        for (i = 0; i < nb_Villes; i++) {
            for (j = 0; j < nb_Villes; j++) {
                n1 = tirage(1024);
                n2 = n1 / 19;

                while (n2 < 10) {
                    n1 = tirage(1024);
                    n2 = n1 / 19;

                }
                if (i == j) {
                    matrice_dis[i][j] = 0;
                } else {
                    matrice_dis[i][j] = n2;
                }
            }
            System.out.println("\n");
        }

    }

    int algo_gen_alea() {
        nb_fils = 0;
        int i = 0;
        double c1 = 0;

        int indice_meill = 0, l;
        attrapeVille(nbVilles, Ville);
        creerIndividus(); //1 ville de depart  7:nbindividus
//        if (choix == 1) {
//            matrice_dis_alea(nbVilles);  //5 nb_ville
//
//        } else if (choix == 2) {
//            matrice_dis_manu();
//        } else {
//            LireXML c = new LireXML();
//            matrice_dis = c.matFromXML("a280.xml").getDistance();
//        }
        int p = nbIndividu / 3;
        //Instanciation de la matrice qui contient la meilleur solution de chaque génération
        dataAGsolution = new String[nb_genera][3];
        GenererINdividuHeuristique(p);
        String tmp = new String();
        int cptData = 0;
        for (i = 0; i < nb_genera; i++) {
            calcul_cout();
            if (i > 0) {
                c1 = (int) tab_cout[0];
            }
            classement();
            indice_meill = tab_indid_tri[0];
            tmp = "";
            if (c1 != tab_cout[0]) {
                System.out.println("\n le cout de la meilleure solution:  \n" + tab_cout[0]);
                System.out.println("la solution: \n");
                for (l = 0; l < nbVilles; l++) {
                    System.out.print("| " + population_ini[indice_meill][l] + " |");
                    tmp = tmp.concat(" | " + population_ini[indice_meill][l]);
                }
                System.out.println("\n");

            }
            if (tmp.length() > 0) {
                dataAGsolution[cptData][0] = "" + i;
                dataAGsolution[cptData][1] = tmp;
                dataAGsolution[cptData][2] = "" + tab_cout[0];
                cptData++;
            }

            croisement_g_alea();
            migration();
        }
        calcul_cout();
        classement();
        return indice_meill;
    }

    void croisement_g_alea() {
        int exist[];
        exist = new int[nbIndividu];
        int in1, in2, i, r = 0;
        double p;
        for (i = 0; i < nbIndividu; i++) {
            exist[i] = 0;
        }

        int o;
        for (o = 0; o < nbIndividu / 2; o++) {
            in1 = tirage(nbIndividu);
            exist[r] = in1;
            r++;
            in2 = tirage(nbIndividu);
            int res = exi(exist, in2);
            exist[r] = in2;
            r++;
            p = proba();

            if (p < proba_coise) {
                croisement(in1, in2);
            } else {
                parent_fils(in1);
                parent_fils(in2);
            }
        }
    }

    void migration_eliteste() {
        int i, j;

        for (i = 0; i < nb_fils; i++) {
            for (j = 0; j < nbVilles; j++) {
                population_ini[i][j] = population_ini[tab_indid_tri[i]][j];
            }
        }

        for (i = 0; i < nb_fils; i++) {
            for (j = 0; j < nbVilles; j++) {
                population_ini[nb_fils + i][j] = fils[i][j];
            }
        }
        nb_fils = 0;
    }

    /**
     * ***************************
     */
    double eval = 0;

    void PProche_Voisin(int sometDepart, int NbrSommets) {
        int h = 0, hh = 0;
        NbrSommets = nbVilles;

        Dist = new double[nbVilles][nbVilles];

        for (h = 0; h < NbrSommets; h++) {
            for (hh = 0; hh < NbrSommets; hh++) {
                Dist[h][hh] = matrice_dis[h][hh]; // matrice distance est une matrice globale
            }
        }
        Tour = new int[nbVilles];
        sommetVisite = new int[nbVilles];
        //int *Tour = malloc(NbrSommets * sizeof(int)); // Le tour construit
        //int *sommetVisite  = malloc(NbrSommets * sizeof(int)); // La liste de sommets visités "0"-->visité "1" --> Non visité

        int ii = 0, jj = 0;

        // Initialiser la list des sommets visité
        int l = 0;
        for (l = 0; l < NbrSommets; l++) {
            sommetVisite[l] = 1;
        }

        int vi; // Le sommet en court
        int vj = 0; // Le sommet suivant dans le chemin
        int nbrSommVisite = 0; // Le nombre de sommets visités

        vi = sometDepart; // On initialise le sommet départ;
        supprimer_colonne(Dist, vi, NbrSommets); // supprimer la colonne 'vi'

        sommetVisite[vi] = 0; // Marquer le sommet depart visité

        Tour[0] = vi + 1; // Rajouter le sommet initiale ( on rajoute +1 pour commencer de 1)
        while (nbrSommVisite < NbrSommets - 1) // Tant qu'il existe enccore des sommets à visiter
        {
            // On garde le dernier sommets à la fin car le traitement est différent

            vj = calculIndiceMin(Dist, vi, -1, NbrSommets); // On calcul l'indice (la ville) tq d(vi ,vj) est minimale
            // printf(" vi = %d -- vj = %d -- dist = %f \n",vi,vj ,Dist[vi][vj]);
            Tour[nbrSommVisite + 1] = vj + 1; // completer le tour au fur et a mesure avec le plus proche voisin (on rajoute +1 pour commencer de 1)
            eval = eval + Dist[vi][vj]; // Mettre à jour le cout du chemin

            supprimer_ligne(Dist, vi, NbrSommets); // supprimer la ligne courante
            supprimer_colonne(Dist, vj, NbrSommets); // supprimer la colonne rajoutée pour éviter les cyscles

            sommetVisite[vi] = 0; // rajouter le sommet vj à la liste des sommets visités
            vi = vj;
            nbrSommVisite++; // on incrémente le nombre de sommet visité
        }

        // Rechercher le dernier sommet (celui qui n'est pas encore visité)
        int i = 0;
        int trouve = 0;
        while (trouve == 0 && i < NbrSommets) {
            if (sommetVisite[i] == 1) // Le sommet n'est pas visité
            {
                trouve = 1;
            }
            i++;
        }
        i = i - 1; // Récupérer la ville non encore visité
        if (trouve == 1) // Si on a trouvé le dernier sommet non visité
        {
            Tour[NbrSommets - 1] = i + 1; // completer le tour avec le dernier sommet (+1 por commencer de 1)
            eval = eval + Dist[i][sometDepart]; // Mettre à jour le cout du chemin
            sommetVisite[i] = 0; // Marquer le sommet visité
        }

    }

    /**
     * Elle permet de supprimer la ligne 'i' de la matrice 'Dist'
     *
     * @param Dist : la matrice des distances de notre graphe
     * @param i : la ligne à supprimer
     * @param Tail : le nombre de sommet
     */
    void supprimer_ligne(double Dist[][], int i, int Tail) {
        int k = 0;
        for (k = 0; k < Tail; k++) {
            //  printf("| %f i= %d k= %d|",Dist[i][k],i,k);
            Dist[i][k] = -1;
            //   printf("| %f |",Dist[i][k]);
        }
    }

    /**
     * Elle permet de supprimer la colonne 'i' de la matrice 'Dist'
     *
     * @param Dist : la matrice des distances de notre graphe
     * @param j : la colonne à supprimer
     * @param Tail : le nombre de sommet
     */
    void supprimer_colonne(double Dist[][], int j, int Tail) {
        int k = 0;
        // printf("| slt j= %d \n",j);
        for (k = 0; k < Tail; k++) {
            //    printf("| %f k= %d j= %d|",Dist[k][j],k,j);
            Dist[k][j] = -1;
            //   printf("| %f |",Dist[k][j]);
        }
    }

    /**
     *
     * @param Dist : la matrice des distances de notre graphe
     * @param i : la ligne
     * @param j : la colone
     * @param Tail : Dimension de la matrices
     *
     * @return L'indice de la valeur minimale dans la ligne "i" ou la colone "j"
     */
    int calculIndiceMin(double Dist[][], int i, int j, int Tail) {
        double mini = 100000;
        int indiceMin = -1;

        if (j == -1) // on calcul le min par rapport à la ligne
        {
            int k = 0;
            for (k = 0; k < Tail; k++) {
                if ((Dist[i][k] != -1) && (Dist[i][k] < mini)) {
                    mini = Dist[i][k];
                    indiceMin = k;
                }
            }
        }

        if (i == -1) // on calcul le min par rapport à la colone
        {
            int k = 0;
            for (k = 0; k < Tail; k++) {
                if ((Dist[k][j] != -1) && (Dist[k][j] < mini)) {
                    mini = Dist[k][j];
                    indiceMin = k;
                }
            }
        }

        return indiceMin;
    }

    void GenererINdividuHeuristique(int nbrIndivGenerer) {
        int sommetDepart = 0; // générer un num de sommet aléatoirement
        int indiceIndivRemplcer = 0; // L'indice de l'individu à remplacer;
        //int *indi = malloc(nbVilles * sizeof(int)); // l'individu
        indi = new int[nbVilles];
        int l = 0, k = 0;
        while (l < nbrIndivGenerer) {
            sommetDepart = (sommetDepart + 1) % (nbVilles);
            PProche_Voisin(sommetDepart, nbVilles);
            indiceIndivRemplcer = generer_Sommet(0, nbIndividu);
            k = 0;
            while (k < nbVilles) {
                population_ini[indiceIndivRemplcer][k] = Tour[k];
                k++;
            }
            l++;
        }
    }

    int generer_Sommet(int minn, int maxx) {
        //srand(time(NULL));
        return tirage(maxx);//rand()%(maxx-minn+1) + minn;
    }

    public void recopierMatriceDistance(double MDist[][], int tail) {

        Utilitaire.recopierMatrice(MDist, matrice_dis, tail);
    }

    public int[] getTour() {
        return Tour;
    }

    public void setTour(int[] Tour) {
        this.Tour = Tour;
    }

    public double[][] getMatrice_dis() {
        return matrice_dis;
    }

    public void setMatrice_dis(double[][] matrice_dis) {
        this.matrice_dis = matrice_dis;
    }

    public int getNbIndividu() {
        return nbIndividu;
    }

    public void setNbIndividu(int nbIndividu) {
        this.nbIndividu = nbIndividu;
    }

    public int getNbVilles() {
        return nbVilles;
    }

    public void setNbVilles(int nbVilles) {
        this.nbVilles = nbVilles;
    }

    public int getNb_genera() {
        return nb_genera;
    }

    public void setNb_genera(int nb_genera) {
        this.nb_genera = nb_genera;
    }

    public int getSele() {
        return sele;
    }

    public void setSele(int sele) {
        this.sele = sele;
    }

    public double getProba_coise() {
        return proba_coise;
    }

    public void setProba_coise(double proba_coise) {
        this.proba_coise = proba_coise;
    }

    public double getProba_mut() {
        return proba_mut;
    }

    public void setProba_mut(double proba_mut) {
        this.proba_mut = proba_mut;
    }

    public int[] getMeilleurIndividu() {
        return null;
    }

    public double getCoutMeilleurIndividu() {
        return 0;
    }
}
