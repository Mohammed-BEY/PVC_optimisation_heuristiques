package TP_OPTM_PVC;

import TP_OPTM_PVC.Model.Chemin;
import TP_OPTM_PVC.Model.Graphe;
import TP_OPTM_PVC.Model.Arc;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class Utilitaire {

    /**
     * Elle permet de supprimer la ligne 'i' de la matrice 'Dist'
     *
     * @param Dist : la matrice des distances de notre graphe
     * @param i : la ligne � supprimer
     * @param Tail : le nombre de sommet
     */
    public static void supprimer_ligne(double[][] Dist, int i, int Tail) {
        int k = 0;
        for (k = 0; k < Tail; k++) {
            Dist[i][k] = Double.POSITIVE_INFINITY;
        }
    }

    /**
     * Elle permet de supprimer la colonne 'i' de la matrice 'Dist'
     *
     * @param Dist : la matrice des distances de notre graphe
     * @param j : la colonne � supprimer
     * @param Tail : le nombre de sommet
     */
    public static void supprimer_colonne(double[][] Dist, int j, int Tail) {

        int k = 0;
        for (k = 0; k < Tail; k++) {
            Dist[k][j] = Double.POSITIVE_INFINITY;
        }
    }

    /**
     *
     * @param Dist : la matrice des distances de notre graphe
     * @param i : la ligne
     * @param j : la colone
     * @param Tail : Dimension de la matrices
     *
     * @return la valeur minimale dans la ligne "i" ou la colone "j"
     */
    public static double calculMin(double[][] Dist, int i, int j, int Tail) {

        double min = Double.POSITIVE_INFINITY;

        if (j == -1) { // on calcul le min par rapport � la ligne
            int k = 0;
            for (k = 0; k < Tail; k++) {
                if ((Dist[i][k] != Double.POSITIVE_INFINITY) && (Dist[i][k] < min)) {
                    min = Dist[i][k];
                }
            }
        }

        if (i == -1) { // on calcul le min par rapport � la colone
            int k = 0;
            for (k = 0; k < Tail; k++) {
                if ((Dist[k][j] != Double.POSITIVE_INFINITY) && (Dist[k][j] < min)) {
                    min = Dist[k][j];
                }
            }
        }

        return min;
    }

    /**
     *
     * @param Dist : la matrice des distances de notre graphe
     * @param i : la ligne
     * @param j : la colone
     * @param Tail : Dimension de la matrices
     *
     * @return L'indice de la valeur minimale dans la ligne "i" ou la colone "j"
     */
    public static int calculIndiceMin(double[][] Dist, int i, int j, int Tail) {

        double min = Double.POSITIVE_INFINITY;
        int indiceMin = -1;

        if (j == -1) { // on calcul le min par rapport � la ligne
            int k = 0;
            for (k = 0; k < Tail; k++) {
                if ((Dist[i][k] != Double.POSITIVE_INFINITY) && (Dist[i][k] < min)) {
                    min = Dist[i][k];
                    indiceMin = k;
                }
            }
        }

        if (i == -1) { // on calcul le min par rapport � la colone
            int k = 0;
            for (k = 0; k < Tail; k++) {
                if ((Dist[k][j] != Double.POSITIVE_INFINITY) && (Dist[k][j] < min)) {
                    min = Dist[k][j];
                    indiceMin = k;
                }
            }
        }

        return indiceMin;
    }

    /**
     *
     * @param Dist : la matrice des distances de notre graphe
     * @param i : la ligne
     * @param SommetAutorise : La liste des sommets SommetAutoris�s i.e on
     * cherche le min parmis les nums de colonnes qui y figure
     * @param Tail : Dimension de la matrices
     *
     * @return L'indice du sommet le plus proche � "i" mais qui figure pas dans
     * la liste de Sommets Autoris�s
     */
    public static int calculIndiceMinLigne(double[][] Dist, int i, int Tail, ArrayList<Integer> SommetAutorise) {

        double min = Double.POSITIVE_INFINITY;
        int indiceMin = -1;

        int k = 0;
        for (k = 0; k < Tail; k++) {
            if ((Dist[i][k] != Double.POSITIVE_INFINITY) && (Dist[i][k] < min && SommetAutorise.contains(k))) {
                min = Dist[i][k];
                indiceMin = k;
            }
        }

        return indiceMin;
    }

    /**
     * Elle permet de supprimer les arcs (vk,vl) qui risque de construire un
     * sous-cycle apr�s l'ajout de l'arc (vi,vj) � PS (ensemble des arcs du
     * chemin)
     */
    public static void supprimer_cycle(int vi, int vj, int NbrSommets, Graphe graphe, ArrayList<Arc> Ps) {
        // int[] vinit =new int[NbrSommets];
        ArrayList<Integer> vinit = new ArrayList<>();
        vinit.add(vi);
        int saveVj = vj;
        int i = 1;
        ArrayList<Arc> tmp = new ArrayList<>();
        tmp.addAll(Ps);
        Iterator<Arc> it;
        Arc arc = null;
        boolean trouv = true;
        while (trouv) {
            trouv = false;
            it = tmp.iterator();
            while (it.hasNext()) {
                arc = it.next();
                if (arc.getSommet1() == vj) {
                    vinit.add(i, vj);
                    i++;
                    trouv = true;
                    for (int j = 0; j < i; j++) {
                        graphe.setValDistance(arc.getSommet2(), vinit.get(j), Double.POSITIVE_INFINITY);
                        //	System.out.println(" Arc ENLEVER est : "+arc.getSommet2()+ " - "+ vinit.get(j)) ;
                    }
                    vj = arc.getSommet2();
                    break;
                }
            }
        }
        vinit.add(i, vj);
        i = 1;
        vj = saveVj;
        ArrayList<Integer> vinit2 = new ArrayList<>();
        vinit2.add(0, vj);
        Iterator<Arc> itt;
        trouv = true;
        while (trouv) {
            trouv = false;
            itt = tmp.iterator();
            while (itt.hasNext()) {
                arc = itt.next();
                if (arc.getSommet2() == vi) {
                    vinit2.add(i, vi);
                    i++;
                    trouv = true;
                    for (int j = 0; j < i; j++) {
                        graphe.setValDistance(vinit2.get(j), arc.getSommet1(), Double.POSITIVE_INFINITY);
                        //	System.out.println(" Arc ENLEVER est : "+vinit2.get(j)+ " - "+arc.getSommet1() ) ;
                    }
                    for (int j = 0; j < vinit.size(); j++) {
                        graphe.setValDistance(vinit.get(j), arc.getSommet1(), Double.POSITIVE_INFINITY);
                        //	System.out.println(" Arc ENLEVER est : "+vinit.get(j)+ " - "+arc.getSommet1() ) ;
                    }
                    vi = arc.getSommet1();
                    break;
                }
            }
        }
    }

    /**
     *
     * @param Dist1 : la matrice originale
     * @param Dist2 : la matrice destination
     * @param tail : la tail des deux matrices
     */
    public static void recopierMatrice(double[][] Dist1, double[][] Dist2, int tail) {

        for (int i = 0; i < tail; i++) {
            for (int j = 0; j < tail; j++) {
                Dist2[i][j] = Dist1[i][j];
            }
        }
    }

    /**
     * @param T : le tour
     * @param sommet : le sommet qu'on veut verifier son apartenance au Tour T
     * @return : null si le sommet n'apartient pas au tour T , sinon return T
     */
    public static String isTourContientSommet(String T, int sommet) {
        if (T.contains("-" + sommet + "-")) {
            return T; // On v�rifie exactement -som- dans le chemin pour eviter d'avoir "vrai" en cherchant 3 dans -13-
        } else {
            return null;
        }
    }

    /**
     *
     * @param Tt : la liste des Tours
     * @param som1 : le sommet 1
     * @param som2 : le sommet 2
     * @return : null si les deux sommets n'appartient pas au meme tour, le tour
     * T sinon
     */
    public static String verif2SommetsMemeTour(ArrayList<String> Tt, int som1, int som2) {
        Iterator<String> it = Tt.iterator();
        String T = null;
        boolean trouve = false;
        System.out.println(" som1 = " + som1 + " som2 = " + som2);
        while (it.hasNext() && !trouve) {
            T = (String) it.next();
            System.out.println(" Tour = " + T);
            if (isTourContientSommet(T, som1) != null && isTourContientSommet(T, som2) != null) {
                trouve = true; // on sort d�s le premier trouver 
            } // car on accepte pas dans la liste des tours identiques ou une partie identique
            else {
                T = null;
            }

        }
        return T;
    }

    /**
     *
     * @param Tt : la liste des Tours
     * @param som1 : le sommet 1
     * @return : null si aucun tour trouver sinon le tour ou som1 figure dedans
     */
    public static String rechercherTourSommet(ArrayList<String> Tt, int som1) {
        Iterator<String> it = Tt.iterator();
        String T = null;
        boolean trouve = false;
        while (it.hasNext() && !trouve) {
            T = (String) it.next();
            if (isTourContientSommet(T, som1) != null) {
                trouve = true; // on sort d�s le premier trouver 
            } // car on accepte pas dans la liste des tours identiques ou une partie identique
            else {
                T = null;
            }

        }
        return T;
    }

    /**
     *
     * @param ch : le tour construit avec Le plus proche voisin
     * @param NbrSommet : nombre de sommets (de villes) de notre instance
     * @return : le tour sous forme d'un tableau ou chaque case est un numeros
     * de ville
     */
    public static int[] CheminToTableau(Chemin ch, int NbrSommet) {

        int[] tour = new int[NbrSommet]; // le tableau qui contienedera les sommets du tour
        Arc ar = null;
        for (int i = 0; i < NbrSommet; i++) {
            ar = ch.getArcs().get(i); // R�cup�rer l'arc d'indice 'i' de la liste des arcs du chemin (les arcs sont ordonn�es car le chemin est obtenue avec le plus proche voisin 
            tour[i] = ar.getSommet1();  // Construire le tableau 
        }

        return tour;
    }

    /**
     *
     * @param nbrSommets : nombre de sommest dans notre graphe
     * @param min : valeur minimale de l'intervale des distances
     * @param max : valeur maximale de l'intervale des distances
     * @return : Le graphe G avec la matrice g�n�r�e
     */
    public static Graphe generateGraphe(int nbrSommets, int min, int max) {
        Graphe g = new Graphe(nbrSommets);
        Random R = new Random();

        double val = 0;
        DecimalFormat f = new DecimalFormat(".###"); // utilis�e pour tranquer en 3 chiffre apr� la virgule

        for (int i = 0; i < nbrSommets; i++) {

            for (int j = 0; j < nbrSommets; j++) {
                if (i == j) { // la diagonale
                    g.setValDistance(i, j, Double.POSITIVE_INFINITY);
                } else {
                    val = R.nextDouble() * (max - min) + min; // On g�n�re un nombre al�atoire dans [min max]
                    val = Double.parseDouble(f.format(val).replace(',', '.'));
                    g.setValDistance(i, j, val);
                }

            }
        }
        return g;
    }

    /**
     *
     * @param nbrSommets : nombre de sommest dans notre graphe
     * @param min : valeur minimale de l'intervale des distances
     * @param max : valeur maximale de l'intervale des distances
     * @return : Le graphe G avec la matrice générée
     */
    public static Graphe generateGrapheSymetric(int nbrSommets, int min, int max) {

        Graphe g = new Graphe(nbrSommets);
        Random R = new Random();

        double val = 0;
        DecimalFormat f = new DecimalFormat(".###"); // utilisée pour tranquer en 3 chiffre apré la virgule

        for (int i = 0; i < nbrSommets; i++) {

            for (int j = i; j < nbrSommets; j++) {
                if (i == j) { // la diagonale
                    g.setValDistance(i, j, Double.POSITIVE_INFINITY);
                } else {
                    val = R.nextDouble() * (max - min) + min; // On génére un nombre aléatoire dans [min max]
                    val = Double.parseDouble(f.format(val).replace(',', '.'));
                    g.setValDistance(i, j, val);
                    g.setValDistance(j, i, val);
                }

            }
        }
        return g;
    }

    public static Chemin tableauToChemin(Graphe g, int tabSolution[]) {
        Chemin ch = new Chemin();
        int i = 0;
        // On rajoute "-1" pour commcer de "0" 
        for (i = 0; i < tabSolution.length - 1; i++) {
            ch.getArcs().add(new Arc(tabSolution[i] - 1, tabSolution[i + 1] - 1, g.getValDistance(tabSolution[i] - 1, tabSolution[i + 1] - 1)));
        }
        i = tabSolution.length - 1;
        // On rajoute l'arrette pour former un cycle
        ch.getArcs().add(new Arc(tabSolution[i] - 1, tabSolution[0] - 1, g.getValDistance(tabSolution[i] - 1, tabSolution[0] - 1)));
        return ch;
    }
    
    public static Chemin StringToChemin(Graphe g, String chem) {
        Chemin ch = new Chemin();
        int i = 0;
        String tabSolutionString[] = chem.split("-");
        int tabSolution[] = new int[g.getNbrSommets()];
        
        for (i = 0; i < tabSolution.length - 1; i++) {
            ch.getArcs().add(new Arc(Integer.parseInt(tabSolutionString[i]), Integer.parseInt(tabSolutionString[i+1]), g.getValDistance(Integer.parseInt(tabSolutionString[i]),Integer.parseInt(tabSolutionString[i+1]))));
        }
        i = tabSolution.length - 1;
        // On rajoute l'arrette pour former un cycle
        ch.getArcs().add(new Arc(Integer.parseInt(tabSolutionString[i]),Integer.parseInt(tabSolutionString[0]), g.getValDistance(Integer.parseInt(tabSolutionString[i]), Integer.parseInt(tabSolutionString[0]))));
        return ch;
    }
}
