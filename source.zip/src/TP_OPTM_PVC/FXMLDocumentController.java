/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TP_OPTM_PVC;

import TP_OPTM_PVC.IHM.AffichageMatrix;
import TP_OPTM_PVC.Algorithme.LireXML;
import TP_OPTM_PVC.Model.Chemin;
import TP_OPTM_PVC.Model.Graphe;
import TP_OPTM_PVC.Model.Arc;
import TP_OPTM_PVC.Model.Noeud;
import TP_OPTM_PVC.Model.PVC_Data;
import TP_OPTM_PVC.IHM.InterfaceGraphique;
import TP_OPTM_PVC.IHM.PVC;
import TP_OPTM_PVC.IHM.ArcDessin;
import TP_OPTM_PVC.Algorithme.AG;
import TP_OPTM_PVC.Algorithme.HeuristiquesVoisinage;
import TP_OPTM_PVC.Algorithme.PVCClarkWright;
import TP_OPTM_PVC.Algorithme.ProcheVoisin;
import TP_OPTM_PVC.Algorithme.PVCInsertion;
import TP_OPTM_PVC.Algorithme.RechercheTabouAtributive;
import TP_OPTM_PVC.Algorithme.PVCLittle;
import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXRadioButton;
import com.jfoenix.controls.JFXSlider;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.FileChooser;
import javafx.util.Duration;
import org.controlsfx.control.Notifications;

/**
 *
 * @author Mohammed_BEY
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    Pane anch;
    @FXML
    Label labelEvaluation;
    @FXML
    Label labelTempsExec;
    @FXML
    Label labelCheminSolution;

    @FXML
    Label labelGenererAleat;
    @FXML
    Label labelIntrodMan;
    @FXML
    Label labelLireFichierXML;
    @FXML
    Label labelAffichGraphe;
    @FXML
    Label labelAffichMtrix;
    //le conteneur principal de l'Editeur
    @FXML
    ScrollPane sp;
    @FXML
    JFXComboBox comboalgoConstr;
    @FXML
    JFXComboBox comboalgoVoisinage;
    @FXML
    JFXComboBox comboStrategieSelection;
    @FXML
    Spinner spinNbSommets;
    @FXML
    Spinner spinSommetInitial;
    @FXML
    Spinner spinNbIterationsTabou;
    @FXML
    Spinner spinTailleFileTabou;
    @FXML
    Spinner spinTaillePopulationAG;
    @FXML
    Spinner spinNbGenerationAG;
    @FXML
    Spinner spinTTLmvnt;
    @FXML
    JFXSlider sliderPc;
    @FXML
    JFXSlider sliderPm;
    @FXML
    JFXCheckBox checkAffichageTableau;
    @FXML
    JFXCheckBox checkAleatAsymetrique;

    @FXML
    JFXRadioButton radbtnMethodeExacte;
    @FXML
    JFXRadioButton radbtnHeurist;
    @FXML
    JFXRadioButton radbtnMetaHeuris;
    @FXML
    JFXRadioButton radbtnMetaHeurisTabou;
    @FXML
    JFXRadioButton radbtnMetaHeurisAG;
    //Définir la liste des algorithmes de Construction
    private ObservableList algosContruct = FXCollections.observableArrayList("Plus Proche Voisin", "Clark & Wright", "Nearest Insertion");
    //Définir la liste des algorithmes de Voisinage
    private ObservableList algosVoisinage = FXCollections.observableArrayList("Algorithme 2-OPT", "Node Reinsertion");
    private ObservableList strategieSelection = FXCollections.observableArrayList("Ellitiste & aléatoire", "Ellitiste", "Aléatoire");
    public static AnchorPane contPrinc = new AnchorPane();//conteneur des objets
    PVCLittle pvc = null;
    PVC_Data data = new PVC_Data();
    Chemin chem = new Chemin();
    Graphe g = null;
    InterfaceGraphique f = null;//pour l'affichage améliorée du déroulement de l'algo du plus proche voisin
    ArrayList tabDessinAlgo;//contient la liste des arcs à dessiner

    @FXML
    public void lireFichierXML() throws InterruptedException {
        FileChooser chooser = new FileChooser();
        chooser.setInitialDirectory(null);
        chooser.setTitle("Ouverture d'un fichier");
        chooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("Fichier Algo", "*.xml", "*.txt"));
        File fichier = chooser.showOpenDialog(null);
        if (fichier != null) {
            g = LireXML.matFromXML(fichier.getPath());
            g.initialiserDistance();
            if (checkAffichageTableau.isSelected()) {//afficher le tableau des distances
                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        AffichageMatrix affichageMatrix = new AffichageMatrix(g.getDistance(), g.getNbrSommets());
                    }
                });
            }
            //Affichage améliorée
            if (f != null) {
                f.dispose();
            }
            f = new InterfaceGraphique(g);
            f.setSize(1280, 650);
            f.show();
            f.initFVilles(g.getNbrSommets());
        }
    }

    @FXML
    public void genererAleat() {
        int nbSommets = 0;
        try {
            nbSommets = Integer.parseInt(spinNbSommets.getEditor().getText());
            if (checkAleatAsymetrique.isSelected()) {//génération d'une instance Asymétrique : valeur par défaut
                g = Utilitaire.generateGraphe(nbSommets, 0, 1000);
            } else {
                g = Utilitaire.generateGrapheSymetric(nbSommets, 0, 1000);

            }
            //afficher la matrice
            if (checkAffichageTableau.isSelected()) {
                Platform.runLater(new Runnable() {
                    @Override
                    public void run() {
                        AffichageMatrix affichageMatrix = new AffichageMatrix(g.getDistance(), g.getNbrSommets());
                    }
                });

            }
            //construire le fichier pour afficher le graphe
            data.listeTransiton.clear();
            String tmp = "";
            for (int i = 0; i < g.getNbrSommets(); i++) {
                for (int j = 0; j < g.getNbrSommets(); j++) {
                    if (i != j) {
                        tmp = i + " " + Double.toString(g.getDistance()[i][j]) + " " + j;
                        data.listeTransiton.add(tmp);//ajouter l'arc à la liste des transitions pour pouvoir afficher le graphe correspondant
                    }
                }
            }
        } catch (NumberFormatException ex) {
            afficherNotif("Veuillez donner le nombre de sommets du graphe");
        } catch (ArrayIndexOutOfBoundsException ex) {
            afficherNotif("Veuillez donner un nombre de sommets du graphe valide");
        }
        //Affichage améliorée
        if (f != null) {
            f.dispose();
        }
        f = new InterfaceGraphique(g);
        f.setSize(1280, 650);
        f.show();
        f.initFVilles(nbSommets);
    }

    @FXML
    public void resoudreProbleme() {
        if (contPrinc.getChildren().size() > 1) {//il y a un graphe introduit par l'user
            g = construireGraphe();
        }
        if (g == null) {
            afficherNotif("Veuilles donner un graphe pour le résoudre");
        } else {
            boolean solutionGeneree = false;//indique si une solution est générée sans erreur.
            long startTime, endTime, temps;
            //Initialisation de lobjet pour écrire dans un fichier CSV
//            PrintWriter buf = null;
//            try {
//                buf = new PrintWriter(new OutputStreamWriter(new FileOutputStream("statistics_2_OPT.csv", true)));
//            } catch (IOException e1) {
//                // TODO Auto-generated catch block
//                e1.printStackTrace();
//            }
//            //Initialisation des colonnes du fichier des statistiques
//            buf.println(" ");
//            buf.println(" Benchmark " + "," + " burma14  ");
//            buf.println("Algorithme de construction" + "," + " Solution exacte " + "," + "Solution initiale" + "," + "Cout Solution" + "," + "Temps d'execution (ms)" + "," + "Qualite/Solution initiale" + "," + "Qualite/Solution exacte");

            Chemin solutionInitiale = null;
            Chemin solutionAmelioree = null;
            Chemin solutionMethodeAG = null;
            int nbIterationsTabou = 0, tailleListeTabou = 0, TTL_ElementListeTabou = 3;
            //Initialisation des variables pour l'algorithme AG (Algorithmes Génétiques
            int taillePopulation = 0, nbGeneration = 0, choixStrategieSelection = 0;
            double probaCroisement = 0, probaMutation = 0;
            //Récupérer le sommet nitial
            int sommetInitial = 0;
            if (!radbtnMethodeExacte.isSelected() && !radbtnHeurist.isSelected() && !radbtnMetaHeuris.isSelected()) {
                afficherNotif("Veuillez choisir un algorithme pour résoudre le problème");
            }
            if (radbtnMethodeExacte.isSelected()) {//Méthode exacte
                solutionGeneree = true;
                resoudreMethoeExacte();
            } else if (radbtnHeurist.isSelected()) {//résoudre avec les heuristiques spécifiques
                try {
                    sommetInitial = Integer.parseInt(spinSommetInitial.getEditor().getText());
                } catch (NumberFormatException ex) {
                    afficherNotif("Veuillez donner le sommet initial");
                }
                //*************************************************************Algorithme de Construction***************************
                if (comboalgoConstr.getSelectionModel().getSelectedIndex() == 0) {//choix de l'algorithme du plus proche voisin
                    //Générer la solution initiale avec la méthode du plus proche voisin
                    ProcheVoisin pprochevoisin = new ProcheVoisin();//Déterminer la solution initiale
                    startTime = System.currentTimeMillis();
                    solutionInitiale = pprochevoisin.PProche_Voisin(g, sommetInitial);
                    endTime = System.currentTimeMillis();
                    temps = endTime - startTime;
                    tabDessinAlgo = pprochevoisin.tabDessin;
                    solutionGeneree = true;
                    System.out.println("Coût initial:" + solutionInitiale.coutSolution(solutionInitiale, g));
                    labelEvaluation.setText(Double.toString(solutionInitiale.coutSolution(solutionInitiale, g)));
                    labelTempsExec.setText(Double.toString(temps) + " ms");
                    labelCheminSolution.setText("Le chemin de la tour:   " + solutionInitiale.chemin_finale(0, g.getNbrSommets()));
                } else if (comboalgoConstr.getSelectionModel().getSelectedIndex() == 1) {//choix de l'algorithme de Clark & Wright
                    //Générer la solution initiale avec la méthode de Clark & Wright
                    PVCClarkWright pclarkWright = new PVCClarkWright();
                    startTime = System.currentTimeMillis();
                    solutionInitiale = pclarkWright.Clark_Wright(g);
                    endTime = System.currentTimeMillis();
                    temps = endTime - startTime;
                    pclarkWright.remplirDessin();
                    tabDessinAlgo = pclarkWright.tabDessin;
                    solutionInitiale = pclarkWright.getChemin();
                    solutionGeneree = true;
                    System.out.println("Coût initial:" + solutionInitiale.coutSolution(solutionInitiale, g));
                    labelEvaluation.setText(Double.toString(solutionInitiale.coutSolution(solutionInitiale, g)));
                    labelTempsExec.setText(Double.toString(temps) + " ms");
                    labelCheminSolution.setText("Le chemin de la tour:   " + solutionInitiale.chemin_finale_Symetric(0, g.getNbrSommets()));

                } else if (comboalgoConstr.getSelectionModel().getSelectedIndex() == 2) {//choix de l'algorithme du Nearest Insertion
                    //Générer la solution initiale avec la méthode du Nearest Insertion  
                    PVCInsertion parinsertion = new PVCInsertion();
                    startTime = System.currentTimeMillis();
                    solutionInitiale = parinsertion.Nearest_insertion(g);
                    endTime = System.currentTimeMillis();
                    temps = endTime - startTime;
                    parinsertion.remplirDessin();
                    tabDessinAlgo = parinsertion.tabDessin;
                    solutionInitiale = parinsertion.getChemin();
                    solutionGeneree = true;
                    System.out.println("Coût initial:" + solutionInitiale.coutSolution(solutionInitiale, g));
                    labelEvaluation.setText(Double.toString(solutionInitiale.coutSolution(solutionInitiale, g)));
                    labelTempsExec.setText(Double.toString(temps) + " ms");
                    labelCheminSolution.setText("Le chemin de la tour:   " + solutionInitiale.chemin_finale_Symetric(0, g.getNbrSommets()));

                } else {
                    afficherNotif("Veuillez choisir un algorithme de construction.");
                }
                //*************************************************************Algorithme de Voisinage******************************
                if (comboalgoVoisinage.getSelectionModel().getSelectedIndex() == 0) {//choix de l'algorithme 2-OPT pour améliorer la solution nitiale
                    if (solutionInitiale == null) {
                        afficherNotif("Veuillez sélectionner un algorithme de construction.");
                    } else {
                        //Améliorer la solution initiale avec l'heuristique "2-OPT"
                        HeuristiquesVoisinage heuris = new HeuristiquesVoisinage();
                        startTime = System.currentTimeMillis();
                        solutionAmelioree = heuris.ameliorerSolution_2_OPT(solutionInitiale, g);
                        endTime = System.currentTimeMillis();
                        temps = endTime - startTime;
                        //enregistrer le résultat dans un fichier CSV
//                        buf.println(comboalgoConstr.getValue() + "," + "3323" + "," + solutionInitiale.coutSolution(solutionInitiale, g) + ","
//                                + solutionAmelioree.coutSolution(solutionAmelioree, g) + ","
//                                + (Double.toString((temps))) + ","
//                                + (Double.toString((solutionAmelioree.coutSolution(solutionAmelioree, g) / solutionInitiale.coutSolution(solutionInitiale, g) * 100))) + "%" + ","
//                                + (Double.toString((3323 / solutionAmelioree.coutSolution(solutionAmelioree, g) * 100))) + " %");
                        tabDessinAlgo = heuris.tabDessin;
                        solutionGeneree = true;
                        labelTempsExec.setText(Double.toString(temps) + " ms");
                        labelCheminSolution.setText("Le chemin de la tour:   " + solutionAmelioree.chemin_finale_Symetric(0, g.getNbrSommets()));
                    }
                } else if (comboalgoVoisinage.getSelectionModel().getSelectedIndex() == 1) {//choix de l'algorithme Node Reinsertion pour améliorer la solution nitiale
                    if (solutionInitiale == null) {
                        afficherNotif("Veuillez sélectionner un algorithme de construction.");
                    } else {
                        //Améliorer la solution initiale avec l'heuristique "Node Reinsertion"
                        HeuristiquesVoisinage heuris = new HeuristiquesVoisinage();
                        startTime = System.currentTimeMillis();
                        solutionAmelioree = heuris.ameliorerSolution_Node_Reinsertion(solutionInitiale, g);
                        endTime = System.currentTimeMillis();
                        temps = endTime - startTime;
                        tabDessinAlgo = heuris.tabDessin;

                        labelEvaluation.setText(Double.toString(solutionAmelioree.coutSolution(solutionAmelioree, g)));
                        solutionGeneree = true;
                        labelEvaluation.setText(Double.toString(solutionAmelioree.coutSolution(solutionAmelioree, g)));
                        labelTempsExec.setText(Double.toString(temps) + " ms");
                        labelCheminSolution.setText("Le chemin de la tour:   " + solutionAmelioree.chemin_finale(0, g.getNbrSommets()));
                    }
                }
            } else if (radbtnMetaHeuris.isSelected()) {//choix d'une metaheuristique
                if (radbtnMetaHeurisTabou.isSelected()) {//La recherche Tabou
                    solutionGeneree = true;
                    RechercheTabouAtributive metaHeurisTabou = new RechercheTabouAtributive();
                    try {
                        nbIterationsTabou = Integer.parseInt(spinNbIterationsTabou.getEditor().getText());
                        tailleListeTabou = Integer.parseInt(spinTailleFileTabou.getEditor().getText());
                        TTL_ElementListeTabou = Integer.parseInt(spinTTLmvnt.getEditor().getText());//10;
                    } catch (NumberFormatException ex) {
                        afficherNotif("Veuillez donner le sommet initial");
                    }
                    metaHeurisTabou.setMaxIterations(nbIterationsTabou);
                    metaHeurisTabou.setTTL_Tabou(TTL_ElementListeTabou);
                    metaHeurisTabou.setTailleListeTabou(tailleListeTabou);
                    startTime = System.currentTimeMillis();
                    solutionAmelioree = metaHeurisTabou.rechTabou(g);
                    endTime = System.currentTimeMillis();
                    temps = endTime - startTime;
                    metaHeurisTabou.remplirDessin();
                    tabDessinAlgo = metaHeurisTabou.tabDessin;

                    labelEvaluation.setText(Double.toString(solutionAmelioree.coutSolution(solutionAmelioree, g)));
                    labelTempsExec.setText(Double.toString(temps) + " ms");
                    labelCheminSolution.setText("Le chemin de la tour:   " + solutionAmelioree.chemin_finale_Symetric(0, g.getNbrSommets()));
                } else if (radbtnMetaHeurisAG.isSelected()) {//La métaheuristique AG
                    probaMutation = sliderPm.getValue() / 100;
                    probaCroisement = sliderPc.getValue() / 100;
                    try {
                        taillePopulation = Integer.parseInt(spinTaillePopulationAG.getEditor().getText());
                    } catch (NumberFormatException ex) {
                        afficherNotif("Veuillez donner le sommet initial");
                    }
                    try {
                        nbGeneration = Integer.parseInt(spinNbGenerationAG.getEditor().getText());
                    } catch (NumberFormatException ex) {
                        afficherNotif("Veuillez donner le sommet initial");
                    }
                    choixStrategieSelection = comboStrategieSelection.getSelectionModel().getSelectedIndex() + 1;
                    AG metaheurisAG = new AG();
                    metaheurisAG.setNbIndividu(taillePopulation);
                    metaheurisAG.setNbVilles(g.getNbrSommets());
                    metaheurisAG.setNb_genera(nbGeneration);
                    metaheurisAG.setProba_coise(probaCroisement);
                    metaheurisAG.setProba_mut(probaMutation);
                    metaheurisAG.setSele(choixStrategieSelection);
                    metaheurisAG.recopierMatriceDistance(g.getDistance(), g.getNbrSommets());
                    solutionGeneree = true;
                    startTime = System.currentTimeMillis();
                    solutionMethodeAG = metaheurisAG.LancerAG();
                    endTime = System.currentTimeMillis();
                    Platform.runLater(new Runnable() {
                        @Override
                        public void run() {
                            AffichageMatrix affichageAG = new AffichageMatrix();
                            affichageAG.afficherGenarationAG(metaheurisAG.dataAGsolution, g.getNbrSommets());
                        }
                    });
                    tabDessinAlgo = metaheurisAG.tabDessin;
                    temps = endTime - startTime;
                    labelEvaluation.setText(Double.toString(solutionMethodeAG.getEval()));
                    labelTempsExec.setText(Double.toString(temps) + " ms");
                    labelCheminSolution.setText("Le chemin de la tour:   " + solutionMethodeAG.chemin_finale_Symetric(0, g.getNbrSommets()));
                }
            } else {
                afficherNotif("Veuillez choisir une méthode pour résoudre le problème.");
            }
            if (solutionGeneree) {
                f.setAlwaysOnTop(true);
                f.startAlgo(tabDessinAlgo);
                f.setAlwaysOnTop(false);
            }
//            buf.close();
        }
    }

    @FXML

    public void afficherGraphe() throws IOException, InterruptedException {
        File defaultDirectory = new File(".\\graphes");//initialiser le répertoire par défaut
        if (!defaultDirectory.exists()) {
            defaultDirectory.mkdir();
        }
        //****Sauvegarder l'état du graphe dans un fichier
        String NomFichier = ".\\graphes\\graph.txt";
        try {
            try (PrintWriter out = new PrintWriter(new FileWriter(NomFichier))) {
                if (contPrinc.getChildren().size() > 1) {//il y a des éléments dans le o=conteneur principal donc on lesaffiche
                    data.insererArc();
                }
                String graph = data.graphStatus(this.chem);
                out.println(graph);
            }
        } catch (IOException e) {
        }
        try {
            Runtime.getRuntime().exec(".\\graphviz\\dot.exe -Tpng "
                    + defaultDirectory + "\\graph.txt -o "
                    + defaultDirectory + "\\auto.png").waitFor();
        } catch (IOException ex) {
        }
        String[] commands = {
            //                "cmd.exe", "/c", "start", "\"DummyTitle\"", "\"" + ".\\src\\tp1_thp\\images\\auto.png" + "\""
            "cmd.exe", "/c", "start", "\"DummyTitle\"", "\"" + ".\\graphes\\auto.png" + "\""
        };
        Process p = Runtime.getRuntime().exec(commands);
        try {
            p.waitFor();
        } catch (InterruptedException ex) {
        }
    }

    public void afficherGrapheSolution() throws IOException, InterruptedException {
        File defaultDirectory = new File(".\\graphes");//initialiser le répertoire par défaut
        if (!defaultDirectory.exists()) {
            defaultDirectory.mkdir();
        }
        //****Sauvegarder l'état du graphe dans un fichier
        String NomFichier = ".\\graphes\\graph.txt";
        try {
            try (PrintWriter out = new PrintWriter(new FileWriter(NomFichier))) {
                if (contPrinc.getChildren().size() > 1) {//il y a des éléments dans le o=conteneur principal donc on lesaffiche
                    data.insererArc();
                }
                String graph = data.graphStatus(this.chem);
                out.println(graph);
            }
        } catch (IOException e) {
        }
        try {
            Runtime.getRuntime().exec(".\\graphviz\\dot.exe -Tpng "
                    + defaultDirectory + "\\graph.txt -o "
                    + defaultDirectory + "\\auto.png").waitFor();
        } catch (IOException ex) {
        }
        String[] commands = {
            //                "cmd.exe", "/c", "start", "\"DummyTitle\"", "\"" + ".\\src\\tp1_thp\\images\\auto.png" + "\""
            "cmd.exe", "/c", "start", "\"DummyTitle\"", "\"" + ".\\graphes\\auto.png" + "\""
        };
        Process p = Runtime.getRuntime().exec(commands);
        try {
            p.waitFor();
        } catch (InterruptedException ex) {
        }
    }

    //ajouter la liste des arcs dans la liste des transitions pour construire le graphe
    private Graphe construireGraphe() {
        int nbSommet = (int) (1 + Math.sqrt(1 + 4 * (contPrinc.getChildren().size() - 1))) / 2;
        g = null;
        g = new Graphe(nbSommet);
        int size = contPrinc.getChildren().size();
        int ville1, ville2;
        double distance;
        String tmp = "";
        g.initialiserDistance();
        data.listeTransiton.clear();
        for (int i = 1; i < size; i++) {
            tmp = contPrinc.getChildren().get(i).toString();
            String[] tab = tmp.split(" ");
            ville1 = Integer.parseInt(tab[0]);
            ville2 = Integer.parseInt(tab[2]);
            distance = Double.parseDouble(tab[1]);
            g.setValDistance(ville1 - 1, ville2 - 1, distance);
            //ajouter l'arc à la liste des transitions pour pouvoir afficher le graphe correspondant
            data.listeTransiton.add(tmp);
        }
        return g;
    }

    //afficher une notification en montrant l'erreur
    private void afficherNotif(String message) {
        Notifications notificationBuilder = Notifications.create()
                .title("Erreurs détectés")
                .text(message)
                .hideAfter(Duration.seconds(5))
                .position(Pos.CENTER);

        notificationBuilder.showWarning();
    }

    //Résoudre le PVC avec la méthode exacte "LITTLE"
    private void resoudreMethoeExacte() {
        long tempExec = 0;
        pvc = new PVCLittle();
        Graphe gLittle = new Graphe(g.getNbrSommets());
        Utilitaire.recopierMatrice(g.getDistance(), gLittle.getDistance(), g.getNbrSommets());
        gLittle.setNbrSommets(g.getNbrSommets());
        Noeud N = new Noeud(gLittle.getNbrSommets());
        N.setGraphe(gLittle);
        tempExec = pvc.Branch_Bound(N, g.getNbrSommets());

        Chemin ch = pvc.getMeilleurChemin().get(pvc.getMeilleurChemin().size() - 1);
        labelEvaluation.setText(Double.toString(ch.getEval()));
        labelTempsExec.setText(Long.toString(tempExec) + " ms");
        labelCheminSolution.setText("Le chemin de la tour:   " + ch.chemin_finale(0, g.getNbrSommets()));
        //remplir la liste des arcs pour le dessin
        Arc tmp = null;
        tabDessinAlgo.clear();
        for (Arc arc : ch.getArcs()) {
            tmp = new Arc(arc.getSommet1(), arc.getSommet2(), arc.getDist());
            tabDessinAlgo.add(new ArcDessin(tmp)); // Pour le dessin
        }
        chem.getArcs().clear();
        //copier les arcs
        int sommetI, sommetJ;
        double distanceij;
        for (int k = 0; k < ch.getArcs().size(); k++) {
            sommetI = ch.getArcs().get(k).getSommet1();
            sommetJ = ch.getArcs().get(k).getSommet2();
            distanceij = ch.getArcs().get(k).getDist();
            chem.getArcs().add(new Arc(sommetI, sommetJ, distanceij));
        }
        chem.setEval(ch.getEval());
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        spinNbSommets.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 10000));
        spinNbIterationsTabou.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 10000));
        spinSommetInitial.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 10000));
        spinTailleFileTabou.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 10000));
        spinTaillePopulationAG.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 10000));
        spinTTLmvnt.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 100));
        spinNbGenerationAG.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 10000));
        sp.setContent(contPrinc);
        contPrinc.getStyleClass().add("anchorpane");
        comboalgoConstr.setItems(algosContruct);
        comboalgoVoisinage.setItems(algosVoisinage);
        comboStrategieSelection.setItems(strategieSelection);
        PVC pvc = new PVC();
        tabDessinAlgo = new ArrayList();
    }
}

// JFXSlider slider = new JFXSlider();
//sliderPc.valueProperty().addListener(new ChangeListener<Number>() {
//            public void changed(ObservableValue<? extends Number> ov, Number old_val, Number new_val) {
//                System.out.println("value:" + sliderPc.getValue() / 100);
//            }
//        });
