package TP_OPTM_PVC;

public class Mouvement implements Comparable<Mouvement> {

    private int arcIJ;
    private int arcKL;
    private double coutApresPermutation;
    private int TTL_Tabou;

    public int getArcIJ() {
        return arcIJ;
    }

    public void setArcIJ(int arcIJ) {
        this.arcIJ = arcIJ;
    }

    public int getArcKL() {
        return arcKL;
    }

    public void setArcKL(int arcKL) {
        this.arcKL = arcKL;
    }

    public double getCoutApresPermutation() {
        return coutApresPermutation;
    }

    public void setCoutApresPermutation(double coutApresPermutation) {
        this.coutApresPermutation = coutApresPermutation;
    }

    public int getTTL_Tabou() {
        return TTL_Tabou;
    }

    public void setTTL_Tabou(int TTL_Tabou) {
        this.TTL_Tabou = TTL_Tabou;
    }

    public Mouvement() {
    }

    public Mouvement(int arcIJ, int arcKL, double coutApresPermutation, int TTL_Tabou) {
        this.arcIJ = arcIJ;
        this.arcKL = arcKL;
        this.coutApresPermutation = coutApresPermutation;
        this.TTL_Tabou = TTL_Tabou;
    }

    @Override
    public String toString() {
        return "Mouvement{" + "arcIJ=" + arcIJ + ", arcKL=" + arcKL + ", coutApresPermutation=" + coutApresPermutation + ", TTL_Tabou=" + TTL_Tabou + '}';
    }

    @Override
    public int compareTo(Mouvement o) {
        int result = 0;
        if (this.getCoutApresPermutation() > o.getCoutApresPermutation()) {
            result = 1;
        } else if (this.getCoutApresPermutation() < o.getCoutApresPermutation()) {
            result = -1;
        }
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        return this.getArcIJ() == ((Mouvement) obj).getArcIJ() && this.getArcKL() == ((Mouvement) obj).getArcKL();
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 43 * hash + this.arcIJ;
        hash = 43 * hash + this.arcKL;
        return hash;
    }

}
