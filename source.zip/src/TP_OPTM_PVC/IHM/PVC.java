/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TP_OPTM_PVC.IHM;

import static TP_OPTM_PVC.FXMLDocumentController.contPrinc;

/**
 *
 * @author Mohammed_BEY
 */
public class PVC {

    public PVC() {
        contPrinc.getChildren().add(new EnsembleVilles());
    }

}
