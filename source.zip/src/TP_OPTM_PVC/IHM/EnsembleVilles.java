/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TP_OPTM_PVC.IHM;

import TP_OPTM_PVC.IHM.Ville;

/**
 *
 * @author mohammed_bey
 */
public class EnsembleVilles extends Ville {

    public EnsembleVilles() {
        super();
        icMAJ.menuSupprimer.setDisable(true);
        label1.setText("Ensemble des villes :");
        getChildren().clear();
        getChildren().addAll(label1, icMAJ);
    }

    @Override
    public String toString() {
        return "Ensemble des villes :";
    }
}
