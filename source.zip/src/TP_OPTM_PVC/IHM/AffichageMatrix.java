/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TP_OPTM_PVC.IHM;

import java.util.Arrays;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn.CellDataFeatures;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.util.Callback;

public class AffichageMatrix {

    TableView<String[]> table;

    public AffichageMatrix() {
    }

    public AffichageMatrix(double[][] matriceDistance, int nbObjets) {
        StackPane root = new StackPane();
        Stage primaryStage = new Stage();
//        primaryStage.setResizable(false);

        String[][] staffArray = convertirIntStringMatrix(matriceDistance, nbObjets);

        ObservableList<String[]> data = FXCollections.observableArrayList();
        data.addAll(Arrays.asList(staffArray));
        table = new TableView<>();
        for (int i = 0; i < nbObjets + 1; i++) {
            TableColumn tc = new TableColumn("");
            final int colNo = i;
            tc.setCellValueFactory(new Callback<CellDataFeatures<String[], String>, ObservableValue<String>>() {
                @Override
                public ObservableValue<String> call(CellDataFeatures<String[], String> p) {
                    return new SimpleStringProperty((p.getValue()[colNo]));
                }
            });
            tc.setPrefWidth(60);
            tc.setStyle("-fx-alignment:center;");
            table.getColumns().add(tc);
        }
        table.setItems(data);
        root.getChildren().add(table);
        primaryStage.setScene(new Scene(root, 60 * (nbObjets + 1) + 5, (nbObjets + 1) * 21 + 21 * 3.5));
        primaryStage.show();
    }

    //Afficher les génération de l'AG
    public void afficherGenarationAG(String[][] staffArray, int nbSommets) {
        StackPane root = new StackPane();
        Stage primaryStage = new Stage();
        ObservableList<String[]> data = FXCollections.observableArrayList();
        data.addAll(Arrays.asList(staffArray));
        table = new TableView<>();
        for (int i = 0; i < 3; i++) {
            TableColumn tc = new TableColumn("");
            final int colNo = i;
            tc.setCellValueFactory(new Callback<CellDataFeatures<String[], String>, ObservableValue<String>>() {
                @Override
                public ObservableValue<String> call(CellDataFeatures<String[], String> p) {
                    return new SimpleStringProperty((p.getValue()[colNo]));
                }
            });
            tc.setStyle("-fx-alignment:center;");
            table.getColumns().add(tc);
        }
        table.getColumns().get(0).setPrefWidth(60);
        table.getColumns().get(1).setPrefWidth(nbSommets * 23);
        table.getColumns().get(2).setPrefWidth(60);

        table.setItems(data);
        root.getChildren().add(table);
        primaryStage.setScene(new Scene(root, 60 + 24 * nbSommets + 60, staffArray.length * 23 + 30));
        primaryStage.show();
    }

    //convertir la matrice solution des réels en chaîne de caractères
    private String[][] convertirIntStringMatrix(double[][] matriceDistance, int nbVilles) {
        String[][] result = new String[nbVilles + 1][nbVilles + 1];
        //initialiser la 1ère case à vide
        result[0][0] = "";
        //mettre dans la 1ère ligne le numéro de la ligne
        for (int i = 0; i < nbVilles; i++) {
            result[0][i + 1] = Integer.toString(i);
        }
        //mettre dans la 1ère colonne le numéro de la colonne
        for (int i = 0; i < nbVilles; i++) {
            result[i + 1][0] = Integer.toString(i);
        }
        for (int i = 0; i < nbVilles; i++) {
            for (int j = 0; j < nbVilles; j++) {
                result[i + 1][j + 1] = Double.toString(matriceDistance[i][j]);
            }
        }
        return result;
    }
}
