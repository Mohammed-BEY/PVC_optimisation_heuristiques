/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TP_OPTM_PVC.IHM;

import TP_OPTM_PVC.TP_OPTM_PVC;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuBuilder;
import javafx.scene.control.MenuItem;
import javafx.scene.control.MenuItemBuilder;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 *
 * @author mohammed_bey
 */
public class iconeMajInst extends MenuBar {

    public Menu menuMiseAjour;
    public MenuItem menuAjouter, menuSupprimer;

    public iconeMajInst() {
        menuAjouter = MenuItemBuilder.create().text("ajouter une instruction").build();
        menuSupprimer = MenuItemBuilder.create().text("supprimer l'instruction").build();

        Image image = new Image(TP_OPTM_PVC.class.getResourceAsStream("images/box_add.png"));
        ImageView picture = new ImageView(image);
        picture.setFitHeight(15);
        picture.setFitWidth(15);
        menuMiseAjour = MenuBuilder.create()
                .graphic(picture)
                .items(menuAjouter, menuSupprimer).build();
        getMenus().addAll(menuMiseAjour);
        menuMiseAjour.setStyle("-fx-background-color:white;");
        getStyleClass().add("icMAJ");
    }

}
