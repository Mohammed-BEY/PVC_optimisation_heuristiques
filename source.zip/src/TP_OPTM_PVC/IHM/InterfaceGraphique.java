package TP_OPTM_PVC.IHM;

import TP_OPTM_PVC.Model.Graphe;
import TP_OPTM_PVC.IHM.ArcDessin;
import TP_OPTM_PVC.IHM.Point;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridBagConstraints;
import java.awt.GridLayout;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 * Interface graphique pour le projet - Utilise le DesktopPane
 */
public class InterfaceGraphique extends JFrame {

    public ArrayList tabDessinGUI;// contient les �tapes du dessin
    Graphe g;
    Graphe gGUI;
    int typeOptimisation = 1; // 1 pour vitesse, 2 pour m�moire 

    javax.swing.Timer timer;

    JInternalFrame dessin;

    JDesktopPane desktop;

    PanelDessin panelDessin;

    GridBagConstraints gbc = new GridBagConstraints();

    /**
     * Constructeur de l'InterfaceGraphique
     */
    public InterfaceGraphique(Graphe g) {
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setTitle("Visualisation des heuristiques du PVC");
        LayoutManager[] layouts = {new FlowLayout(), new GridLayout(1, 0)};
        desktop = new JDesktopPane();
        setContentPane(desktop);

        this.g = g;
        panelDessin = new PanelDessin(g, 10, 100);

        dessin = new JInternalFrame();
        dessin.setVisible(true);
        dessin.setSize(1280, 610);

        desktop.add(dessin);
        dessin.setLocation(0, 0);
        setLocation(20, 10);
    }

    /**
     * Affiche la fen�tre "manque de m�moire"
     */
    public void afficheWarning() {
        JOptionPane.showMessageDialog(this, "    PVC - Le Probl�me du Voyageur de Commerce \n\n M�moire insuffisante: changez de mode", "Warning", JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * M�thode d'initialisation de la frame Villes
     */
    public void initFVilles(int nbSommets) {
        try {
            gGUI = new Graphe(nbSommets, dessin.getWidth() - 50, dessin.getHeight() - 50);
        } catch (OutOfMemoryError ome) {
            afficheWarning();
        }

        dessin.remove(panelDessin);
        panelDessin.graphe = gGUI;
        panelDessin.typeAlgo = 100;
        dessin.getContentPane().add(panelDessin);
        desktop.validate();
        dessin.repaint();
    }

    /**
     * Action lors d'un clic sur le bouton D�marrer
     *
     * @param avecAffichage 1 si on veut l'affichage complet, 2 sinon
     */
    public void startAlgo(ArrayList tabDessinAlgo) {
        int vitesse = 7;
        vitesse = (10 - vitesse) * 100;
        if (panelDessin != null) {
            dessin.remove(panelDessin);
        }

        if (timer != null) {
            timer.stop();
        }
        startTimer(vitesse);
        tabDessinGUI = tabDessinAlgo;

        panelDessin.etape = 1;

        panelDessin.graphe = gGUI;
        panelDessin.vitesse = vitesse;
        panelDessin.typeAlgo = 6;
        dessin.getContentPane().add(panelDessin);
        dessin.validate();
        panelDessin.repaint();
    }

    public void startTimer(int vitesse) {
        ActionListener taskPerformer;
        taskPerformer = new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                panelDessin.etape++;
                desktop.repaint();
            }
        };
        timer = new javax.swing.Timer(vitesse, taskPerformer);
        timer.start();
    }

    /**
     * Classe Interne MonPanel Contenant le dessin du graphe
     */
    public class PanelDessin extends JPanel {

        protected Graphe graphe;
        protected int etape;
        protected int vitesse;
        protected int typeAlgo;
        protected int i;

        public PanelDessin() {
        }

        /**
         * Constructeur du panel de dessin
         *
         * @param g le graphe
         * @param v la vitesse d'affichage
         * @param alg le num�ro de l'algo selectionn�
         * @param a l'algo
         */
        public PanelDessin(Graphe g, int v, int alg) {
            vitesse = v;
            typeAlgo = alg;
            graphe = g;
            i = 0;
            this.setBackground(Color.BLACK);
        }

        /**
         * M�thode paintComponent fournissant le contexte graphique pour
         * dessiner
         */
        @Override
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.setColor(Color.blue);
            i = 0;
            switch (typeAlgo) {
                case 0:
                case 1:
                case 2:
                case 3:
                case 5:
                case 6:
                    i = 0;
                    while (i < tabDessinGUI.size() && i < etape) {
                        dessineArc(i, g);
                        ++i;
                    }
                    break;
                default:
                    break;
            }
            //dessin des points
            for (int i = 0; i < graphe.getNbrSommets(); i++) {
                Point p = graphe.tabPoint[i];
                g.setColor(Color.red);
                g.drawOval(p.getX() - 2, p.getY() - 2, 2 * 5, 2 * 5);
            }
        }

        /**
         * Dessine un arc ou l'enl�ve
         *
         * @param i l'arc a dessiner
         * @param g le contexte graphique
         */
        public void dessineArc(int i, Graphics g) {
            g.setColor(Color.WHITE);
            // Définir la police
            g.setFont(new Font("Courier", Font.BOLD, 25));
            g.drawLine(graphe.tabPoint[((ArcDessin) tabDessinGUI.get(i)).p1].getX(),
                    graphe.tabPoint[((ArcDessin) tabDessinGUI.get(i)).p1].getY(),
                    graphe.tabPoint[((ArcDessin) tabDessinGUI.get(i)).p2].getX(),
                    graphe.tabPoint[((ArcDessin) tabDessinGUI.get(i)).p2].getY());
            g.setColor(Color.yellow);
            g.drawString(Integer.toString(((ArcDessin) tabDessinGUI.get(i)).p1),
                    graphe.tabPoint[((ArcDessin) tabDessinGUI.get(i)).p1].getX() - 4,
                    graphe.tabPoint[((ArcDessin) tabDessinGUI.get(i)).p1].getY() - 4);
        }
    }
}
