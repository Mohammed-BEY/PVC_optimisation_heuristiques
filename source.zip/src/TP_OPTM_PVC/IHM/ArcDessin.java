package TP_OPTM_PVC.IHM;

import TP_OPTM_PVC.Model.Arc;

public class ArcDessin {

    public int p1;
    public int p2;
    protected double distance;

    public ArcDessin(Arc a) {
        this.p1 = a.getSommet1();
        this.p2 = a.getSommet2();
        this.distance = a.getDist();
    }

    public ArcDessin(ArcDessin a) {
        this.p1 = a.p1;
        this.p2 = a.p2;
        this.distance = a.distance;
    }

    public String toString() {
        return "{" + p1 + " � " + p2 + "}";
    }

}
